package com.ysbusiness.smart.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ysbusiness.smart.ui.theme.Pink
import com.ysbusiness.smart.ui.theme.PinkLight

@Composable
fun PinkButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null
) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier = modifier
            .height(58.dp)
            .background(
                brush = if (enabled) Brush.horizontalGradient(listOf(PinkLight, Pink))
                else Brush.horizontalGradient(listOf(Color.Gray, Color.DarkGray)),
                shape = shape
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Text(text, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (icon != null) {
                Spacer(Modifier.width(10.dp))
                Icon(icon, null, tint = Color.White)
            }
        }
    }
}

@Composable
fun SelectableTile(
    title: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(20.dp)
    Surface(
        modifier = modifier
            .height(128.dp)
            .clickable(onClick = onClick),
        shape = shape,
        color = if (selected) Pink else MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, if (selected) Pink else MaterialTheme.colorScheme.outline.copy(alpha = .55f)),
        shadowElevation = if (selected) 8.dp else 1.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, null, tint = if (selected) Color.White else Pink, modifier = Modifier.size(42.dp))
            Spacer(Modifier.height(12.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.fillMaxWidth())
}

@Composable
fun YSLogo(size: Int = 92) {
    Box(
        modifier = Modifier
            .size(size.dp)
            .background(Brush.linearGradient(listOf(PinkLight, Pink)), RoundedCornerShape(24.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text("YS", color = Color.White, fontWeight = FontWeight.Black, fontSize = (size * .38).sp)
    }
}
