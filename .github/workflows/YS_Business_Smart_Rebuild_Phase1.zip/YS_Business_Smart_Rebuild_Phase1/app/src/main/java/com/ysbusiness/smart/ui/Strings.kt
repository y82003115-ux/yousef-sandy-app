package com.ysbusiness.smart.ui

import com.ysbusiness.smart.data.AppLanguage

class S(private val lang: AppLanguage) {
    private fun pick(ar: String, ku: String, en: String): String = when (lang) {
        AppLanguage.ARABIC -> ar
        AppLanguage.KURDISH -> ku
        AppLanguage.ENGLISH -> en
    }

    val createStore = pick("إنشاء متجر جديد", "دروستکردنی فرۆشگای نوێ", "Create new store")
    val storeType = pick("نوع المتجر", "جۆری فرۆشگا", "Store type")
    val general = pick("متجر عام", "فرۆشگای گشتی", "General")
    val grocery = pick("بقالة", "بەقالی", "Grocery")
    val clothing = pick("ملابس", "جلوبەرگ", "Clothing")
    val pharmacy = pick("صيدلية", "دەرمانخانە", "Pharmacy")
    val currency = pick("العملة الأساسية", "دراوی سەرەکی", "Base currency")
    val next = pick("التالي", "دواتر", "Next")
    val ownerAccount = pick("حساب المالك", "هەژماری خاوەن", "Owner account")
    val fullName = pick("الاسم الكامل", "ناوی تەواو", "Full name")
    val phone = pick("رقم الهاتف", "ژمارەی مۆبایل", "Phone")
    val email = pick("البريد الإلكتروني", "ئیمەیڵ", "Email")
    val password = pick("كلمة المرور", "وشەی نهێنی", "Password")
    val confirmPassword = pick("تأكيد كلمة المرور", "دووبارەکردنەوەی وشەی نهێنی", "Confirm password")
    val accept = pick("أوافق على الشروط", "ڕازیم بە مەرجەکان", "I accept the terms")
    val createAccount = pick("إنشاء الحساب", "دروستکردنی هەژمار", "Create account")
    val login = pick("تسجيل الدخول", "چوونەژوورەوە", "Sign in")
    val identifier = pick("اسم المستخدم أو الهاتف أو البريد", "ناو یان مۆبایل یان ئیمەیڵ", "Username, phone or email")
    val remember = pick("تذكرني", "بمناسەوە", "Remember me")
    val enter = pick("دخول", "چوونەژوورەوە", "Enter")
    val fingerprint = pick("البصمة", "پەنجەمۆر", "Fingerprint")
    val face = pick("الوجه", "ڕووخسار", "Face")
    val home = pick("الرئيسية", "سەرەکی", "Home")
    val welcome = pick("مرحبًا بك", "بەخێربێیت", "Welcome")
    val cashier = pick("الكاشير", "کاشێر", "POS")
    val inventory = pick("المخزون", "کۆگا", "Inventory")
    val customers = pick("العملاء", "کڕیاران", "Customers")
    val reports = pick("التقارير", "ڕاپۆرتەکان", "Reports")
    val expenses = pick("المصروفات", "خەرجییەکان", "Expenses")
    val smartCenter = pick("المركز الذكي", "ناوەندی زیرەک", "Smart center")
    val todaySales = pick("إجمالي المبيعات اليوم", "کۆی فرۆشتنی ئەمڕۆ", "Today sales")
    val invoices = pick("الفواتير", "پسولەکان", "Invoices")
    val lowStock = pick("منتجات منخفضة المخزون", "کاڵای کەم", "Low stock")
    val dueInvoices = pick("فواتير آجلة مستحقة", "پسولەی دواخراو", "Due invoices")
    val notReady = pick("سيبدأ هذا القسم في المرحلة التالية", "ئەم بەشە لە قۆناغی داهاتوو دەست پێدەکات", "This section starts in the next phase")
    val invalidLogin = pick("بيانات الدخول غير صحيحة", "زانیاری چوونەژوورەوە هەڵەیە", "Invalid sign-in details")
    val completeFields = pick("أكمل الحقول المطلوبة", "خانە پێویستەکان پڕ بکەرەوە", "Complete required fields")
    val passwordMismatch = pick("كلمتا المرور غير متطابقتين", "وشە نهێنییەکان یەک ناگرنەوە", "Passwords do not match")
    val biometricFirst = pick("سجّل الدخول بكلمة المرور وفعّل تذكرني أولًا", "سەرەتا بە وشەی نهێنی بچۆ ژوورەوە", "Sign in with password and enable remember me first")
    val biometricUnavailable = pick("التحقق الحيوي غير متاح على هذا الجهاز", "پشتڕاستکردنەوەی بایۆمەتری بەردەست نییە", "Biometric authentication is unavailable")
}
