package com.ysbusiness.smart.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ysbusiness.smart.data.*
import com.ysbusiness.smart.security.PasswordHasher
import com.ysbusiness.smart.ui.theme.*
import kotlinx.coroutines.launch

private enum class Screen { STORE, OWNER, LOGIN, DASHBOARD }

@Composable
fun AppRoot(
    preferences: AppPreferences,
    onRequestBiometric: (onSuccess: () -> Unit, onUnavailable: () -> Unit) -> Unit
) {
    val snapshot by preferences.snapshot.collectAsState(initial = null)
    val current = snapshot
    if (current == null) {
        Box(Modifier.fillMaxSize().background(Navy), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Pink)
        }
        return
    }

    var screen by remember { mutableStateOf<Screen?>(null) }
    LaunchedEffect(current.storeCreated, current.ownerCreated) {
        if (screen == null) {
            screen = when {
                !current.storeCreated -> Screen.STORE
                !current.ownerCreated -> Screen.OWNER
                else -> Screen.LOGIN
            }
        }
    }

    val language = current.language
    val direction = if (language == AppLanguage.ENGLISH) LayoutDirection.Ltr else LayoutDirection.Rtl
    val strings = remember(language) { S(language) }
    val scope = rememberCoroutineScope()

    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        YSTheme(darkMode = current.darkMode) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                when (screen) {
                    Screen.STORE -> StoreSetupScreen(
                        s = strings,
                        darkMode = current.darkMode,
                        language = language,
                        onTheme = { scope.launch { preferences.setTheme(it) } },
                        onLanguage = { scope.launch { preferences.setLanguage(it) } },
                        onNext = { type, currency ->
                            scope.launch {
                                preferences.saveStore(type, currency)
                                screen = Screen.OWNER
                            }
                        }
                    )
                    Screen.OWNER -> OwnerScreen(
                        s = strings,
                        onBack = { screen = Screen.STORE },
                        onCreate = { name, phone, email, password ->
                            scope.launch {
                                preferences.saveOwner(name, phone, email, password.toCharArray())
                                screen = Screen.LOGIN
                            }
                        }
                    )
                    Screen.LOGIN -> LoginScreen(
                        s = strings,
                        snapshot = current,
                        onTheme = { scope.launch { preferences.setTheme(it) } },
                        onLanguage = { scope.launch { preferences.setLanguage(it) } },
                        onPasswordLogin = { identifier, password, remember ->
                            val idMatches = identifier.trim().equals(current.phone, true) ||
                                identifier.trim().equals(current.email, true) ||
                                identifier.trim().equals(current.ownerName, true)
                            val passwordMatches = PasswordHasher.verify(
                                password.toCharArray(), current.passwordSalt, current.passwordHash
                            )
                            if (idMatches && passwordMatches) {
                                scope.launch { preferences.enableBiometric(remember) }
                                screen = Screen.DASHBOARD
                                true
                            } else false
                        },
                        onBiometric = {
                            if (!current.biometricEnabled) {
                                false
                            } else {
                                onRequestBiometric(
                                    { screen = Screen.DASHBOARD },
                                    { }
                                )
                                true
                            }
                        }
                    )
                    Screen.DASHBOARD -> DashboardScreen(
                        s = strings,
                        snapshot = current,
                        onTheme = { scope.launch { preferences.setTheme(it) } },
                        onLanguage = { scope.launch { preferences.setLanguage(it) } },
                        onLogout = { screen = Screen.LOGIN }
                    )
                    null -> Unit
                }
            }
        }
    }

    BackHandler(enabled = screen == Screen.OWNER || screen == Screen.DASHBOARD) {
        screen = when (screen) {
            Screen.OWNER -> Screen.STORE
            Screen.DASHBOARD -> Screen.LOGIN
            else -> screen
        }
    }
}

@Composable
private fun StoreSetupScreen(
    s: S,
    darkMode: Boolean,
    language: AppLanguage,
    onTheme: (Boolean) -> Unit,
    onLanguage: (AppLanguage) -> Unit,
    onNext: (StoreType, Currency) -> Unit
) {
    var selectedType by rememberSaveable { mutableStateOf(StoreType.GENERAL) }
    var selectedCurrency by rememberSaveable { mutableStateOf(Currency.IQD) }
    val scroll = rememberScrollState()

    Column(
        Modifier.fillMaxSize().verticalScroll(scroll).padding(horizontal = 22.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopSettings(darkMode, language, onTheme, onLanguage)
        Icon(Icons.Rounded.Storefront, null, tint = Color.White, modifier = Modifier.size(36.dp).background(Pink, RoundedCornerShape(50)).padding(8.dp))
        Spacer(Modifier.height(12.dp))
        Text(s.createStore, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(24.dp))
        SectionTitle(s.storeType)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SelectableTile(s.general, Icons.Rounded.ShoppingCart, selectedType == StoreType.GENERAL, { selectedType = StoreType.GENERAL }, Modifier.weight(1f))
            SelectableTile(s.grocery, Icons.Rounded.ShoppingBasket, selectedType == StoreType.GROCERY, { selectedType = StoreType.GROCERY }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SelectableTile(s.clothing, Icons.Rounded.Checkroom, selectedType == StoreType.CLOTHING, { selectedType = StoreType.CLOTHING }, Modifier.weight(1f))
            SelectableTile(s.pharmacy, Icons.Rounded.LocalPharmacy, selectedType == StoreType.PHARMACY, { selectedType = StoreType.PHARMACY }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(24.dp))
        SectionTitle(s.currency)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilterChip(selected = selectedCurrency == Currency.IQD, onClick = { selectedCurrency = Currency.IQD }, label = { Text("د.ع") }, modifier = Modifier.weight(1f).height(52.dp))
            FilterChip(selected = selectedCurrency == Currency.USD, onClick = { selectedCurrency = Currency.USD }, label = { Text("$") }, modifier = Modifier.weight(1f).height(52.dp))
        }
        Spacer(Modifier.height(26.dp))
        PinkButton(s.next, { onNext(selectedType, selectedCurrency) }, Modifier.fillMaxWidth(), icon = Icons.Rounded.ArrowForward)
        Spacer(Modifier.height(18.dp))
        StepDots(active = 1)
    }
}

@Composable
private fun OwnerScreen(s: S, onBack: () -> Unit, onCreate: (String, String, String, String) -> Unit) {
    val context = LocalContext.current
    var name by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    var accepted by rememberSaveable { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null) }
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.AdminPanelSettings, null, tint = Color.White, modifier = Modifier.size(64.dp).background(Pink, RoundedCornerShape(50)).padding(14.dp))
            Spacer(Modifier.height(12.dp))
            Text(s.ownerAccount, fontSize = 28.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(24.dp))
        AppField(name, { name = it }, s.fullName, Icons.Rounded.PersonOutline)
        AppField(phone, { phone = it }, s.phone, Icons.Rounded.Phone)
        AppField(email, { email = it }, s.email, Icons.Rounded.Email)
        AppField(password, { password = it }, s.password, Icons.Rounded.Lock, password = true)
        AppField(confirm, { confirm = it }, s.confirmPassword, Icons.Rounded.Lock, password = true)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(accepted, { accepted = it })
            Text(s.accept)
        }
        Spacer(Modifier.height(12.dp))
        PinkButton(s.createAccount, {
            when {
                name.isBlank() || phone.isBlank() || password.length < 8 || !accepted -> Toast.makeText(context, s.completeFields, Toast.LENGTH_SHORT).show()
                password != confirm -> Toast.makeText(context, s.passwordMismatch, Toast.LENGTH_SHORT).show()
                else -> onCreate(name, phone, email, password)
            }
        }, Modifier.fillMaxWidth(), icon = Icons.Rounded.PersonAdd)
    }
}

@Composable
private fun LoginScreen(
    s: S,
    snapshot: AppSnapshot,
    onTheme: (Boolean) -> Unit,
    onLanguage: (AppLanguage) -> Unit,
    onPasswordLogin: (String, String, Boolean) -> Boolean,
    onBiometric: () -> Boolean
) {
    val context = LocalContext.current
    var identifier by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var remember by rememberSaveable { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 26.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopSettings(snapshot.darkMode, snapshot.language, onTheme, onLanguage)
        Spacer(Modifier.height(20.dp))
        YSLogo(94)
        Spacer(Modifier.height(14.dp))
        Text("YS Business Smart", fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Spacer(Modifier.height(30.dp))
        Text(s.login, fontSize = 34.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(24.dp))
        AppField(identifier, { identifier = it }, s.identifier, Icons.Rounded.PersonOutline)
        AppField(password, { password = it }, s.password, Icons.Rounded.Lock, password = true)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(remember, { remember = it })
            Text(s.remember)
        }
        Spacer(Modifier.height(12.dp))
        PinkButton(s.enter, {
            if (!onPasswordLogin(identifier, password, remember)) {
                Toast.makeText(context, s.invalidLogin, Toast.LENGTH_SHORT).show()
            }
        }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Login)
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = {
                if (!onBiometric()) Toast.makeText(context, s.biometricFirst, Toast.LENGTH_SHORT).show()
            }, modifier = Modifier.weight(1f).height(56.dp)) {
                Icon(Icons.Rounded.Fingerprint, null, tint = Pink)
                Spacer(Modifier.width(8.dp)); Text(s.fingerprint)
            }
            OutlinedButton(onClick = {
                if (!onBiometric()) Toast.makeText(context, s.biometricFirst, Toast.LENGTH_SHORT).show()
            }, modifier = Modifier.weight(1f).height(56.dp)) {
                Icon(Icons.Rounded.Face, null, tint = Pink)
                Spacer(Modifier.width(8.dp)); Text(s.face)
            }
        }
    }
}

@Composable
private fun DashboardScreen(
    s: S,
    snapshot: AppSnapshot,
    onTheme: (Boolean) -> Unit,
    onLanguage: (AppLanguage) -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val storeName = when (snapshot.storeType) {
        StoreType.GENERAL -> s.general
        StoreType.GROCERY -> s.grocery
        StoreType.CLOTHING -> s.clothing
        StoreType.PHARMACY -> s.pharmacy
    }

    Scaffold(
        topBar = {
            Surface(color = if (snapshot.darkMode) NavyHeader else Color.White, shadowElevation = 2.dp) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    IconButton(onClick = onLogout) { Icon(Icons.Rounded.Logout, null) }
                    Text(storeName, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Row {
                        IconButton(onClick = { onLanguage(nextLanguage(snapshot.language)) }) { Icon(Icons.Rounded.Language, null) }
                        IconButton(onClick = { onTheme(!snapshot.darkMode) }) { Icon(if (snapshot.darkMode) Icons.Rounded.LightMode else Icons.Rounded.DarkMode, null) }
                    }
                }
            }
        },
        bottomBar = { BottomHomeBar(s) }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp)
        ) {
            Text("${s.welcome}، ${snapshot.ownerName}", fontSize = 26.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(20.dp))
            SalesCard(s, snapshot.currency)
            Spacer(Modifier.height(18.dp))
            val cards = listOf(
                Triple(s.cashier, Icons.Rounded.PointOfSale, Pink),
                Triple(s.inventory, Icons.Rounded.Inventory2, Pink),
                Triple(s.customers, Icons.Rounded.Groups, Pink),
                Triple(s.reports, Icons.Rounded.QueryStats, Pink),
                Triple(s.expenses, Icons.Rounded.AccountBalanceWallet, Pink),
                Triple(s.smartCenter, Icons.Rounded.SmartToy, Pink)
            )
            cards.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { (title, icon, color) ->
                        DashboardTile(title, icon, color, Modifier.weight(1f)) {
                            Toast.makeText(context, s.notReady, Toast.LENGTH_SHORT).show()
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
            }
            AlertRow(s.lowStock, "0", Icons.Rounded.WarningAmber)
            Spacer(Modifier.height(10.dp))
            AlertRow(s.dueInvoices, "0", Icons.Rounded.Schedule)
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun TopSettings(darkMode: Boolean, language: AppLanguage, onTheme: (Boolean) -> Unit, onLanguage: (AppLanguage) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        IconButton(onClick = { onLanguage(nextLanguage(language)) }) { Icon(Icons.Rounded.Language, null) }
        IconButton(onClick = { onTheme(!darkMode) }) { Icon(if (darkMode) Icons.Rounded.LightMode else Icons.Rounded.DarkMode, null) }
    }
}

private fun nextLanguage(current: AppLanguage): AppLanguage = when (current) {
    AppLanguage.ARABIC -> AppLanguage.KURDISH
    AppLanguage.KURDISH -> AppLanguage.ENGLISH
    AppLanguage.ENGLISH -> AppLanguage.ARABIC
}

@Composable
private fun AppField(value: String, onChange: (String) -> Unit, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, password: Boolean = false) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        leadingIcon = { Icon(icon, null) },
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        singleLine = true,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
    )
}

@Composable
private fun StepDots(active: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
        (1..4).forEach { n ->
            Surface(shape = RoundedCornerShape(50), color = if (n == active) Pink else Color.Transparent, border = androidx.compose.foundation.BorderStroke(1.dp, if (n == active) Pink else MaterialTheme.colorScheme.outline)) {
                Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) { Text(n.toString(), color = if (n == active) Color.White else MaterialTheme.colorScheme.onBackground) }
            }
        }
    }
}

@Composable
private fun SalesCard(s: S, currency: Currency) {
    Box(
        Modifier.fillMaxWidth().height(176.dp).background(Brush.linearGradient(listOf(PinkLight, Pink)), RoundedCornerShape(24.dp)).padding(22.dp)
    ) {
        Column {
            Text(s.todaySales, color = Color.White.copy(alpha = .9f))
            Spacer(Modifier.height(12.dp))
            Text(if (currency == Currency.IQD) "0 د.ع" else "$0", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(10.dp))
            Text("${s.invoices}: 0", color = Color.White)
        }
        Icon(Icons.Rounded.ShowChart, null, tint = Color.White.copy(alpha = .85f), modifier = Modifier.align(Alignment.CenterEnd).size(94.dp))
    }
}

@Composable
private fun DashboardTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Surface(modifier.clickable(onClick = onClick).height(112.dp), shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface, border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .45f))) {
        Row(Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Icon(icon, null, tint = color, modifier = Modifier.size(36.dp))
        }
    }
}

@Composable
private fun AlertRow(title: String, count: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface, border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .45f))) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Pink)
            Spacer(Modifier.width(14.dp))
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold)
            Badge { Text(count) }
        }
    }
}

@Composable
private fun BottomHomeBar(s: S) {
    NavigationBar {
        NavigationBarItem(selected = true, onClick = {}, icon = { Icon(Icons.Rounded.Home, null) }, label = { Text(s.home) })
        NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Rounded.PointOfSale, null) }, label = { Text(s.cashier) }, enabled = false)
        NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Rounded.Inventory2, null) }, label = { Text(s.inventory) }, enabled = false)
        NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Rounded.Groups, null) }, label = { Text(s.customers) }, enabled = false)
        NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Rounded.MoreHoriz, null) }, label = { Text("•••") }, enabled = false)
    }
}
