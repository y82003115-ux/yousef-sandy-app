package com.ysbusiness.smart.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.ysbusiness.smart.security.PasswordHasher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "ys_business_phase1")

enum class StoreType { GENERAL, GROCERY, CLOTHING, PHARMACY }
enum class Currency { IQD, USD }
enum class AppLanguage { ARABIC, KURDISH, ENGLISH }

data class AppSnapshot(
    val storeCreated: Boolean = false,
    val ownerCreated: Boolean = false,
    val storeType: StoreType = StoreType.GENERAL,
    val currency: Currency = Currency.IQD,
    val ownerName: String = "",
    val phone: String = "",
    val email: String = "",
    val passwordSalt: String = "",
    val passwordHash: String = "",
    val darkMode: Boolean = true,
    val language: AppLanguage = AppLanguage.ARABIC,
    val biometricEnabled: Boolean = false
)

class AppPreferences(private val context: Context) {
    private object Keys {
        val storeCreated = booleanPreferencesKey("store_created")
        val ownerCreated = booleanPreferencesKey("owner_created")
        val storeType = stringPreferencesKey("store_type")
        val currency = stringPreferencesKey("currency")
        val ownerName = stringPreferencesKey("owner_name")
        val phone = stringPreferencesKey("phone")
        val email = stringPreferencesKey("email")
        val passwordSalt = stringPreferencesKey("password_salt")
        val passwordHash = stringPreferencesKey("password_hash")
        val darkMode = booleanPreferencesKey("dark_mode")
        val language = stringPreferencesKey("language")
        val biometricEnabled = booleanPreferencesKey("biometric_enabled")
    }

    val snapshot: Flow<AppSnapshot> = context.dataStore.data.map { p ->
        AppSnapshot(
            storeCreated = p[Keys.storeCreated] ?: false,
            ownerCreated = p[Keys.ownerCreated] ?: false,
            storeType = enumValueOrDefault(p[Keys.storeType], StoreType.GENERAL),
            currency = enumValueOrDefault(p[Keys.currency], Currency.IQD),
            ownerName = p[Keys.ownerName].orEmpty(),
            phone = p[Keys.phone].orEmpty(),
            email = p[Keys.email].orEmpty(),
            passwordSalt = p[Keys.passwordSalt].orEmpty(),
            passwordHash = p[Keys.passwordHash].orEmpty(),
            darkMode = p[Keys.darkMode] ?: true,
            language = enumValueOrDefault(p[Keys.language], AppLanguage.ARABIC),
            biometricEnabled = p[Keys.biometricEnabled] ?: false
        )
    }

    suspend fun saveStore(type: StoreType, currency: Currency) {
        context.dataStore.edit {
            it[Keys.storeCreated] = true
            it[Keys.storeType] = type.name
            it[Keys.currency] = currency.name
        }
    }

    suspend fun saveOwner(name: String, phone: String, email: String, password: CharArray) {
        val result = PasswordHasher.hash(password)
        context.dataStore.edit {
            it[Keys.ownerCreated] = true
            it[Keys.ownerName] = name.trim()
            it[Keys.phone] = phone.trim()
            it[Keys.email] = email.trim()
            it[Keys.passwordSalt] = result.saltBase64
            it[Keys.passwordHash] = result.hashBase64
            it[Keys.biometricEnabled] = false
        }
    }

    suspend fun setTheme(dark: Boolean) {
        context.dataStore.edit { it[Keys.darkMode] = dark }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.language] = language.name }
    }

    suspend fun enableBiometric(enabled: Boolean) {
        context.dataStore.edit { it[Keys.biometricEnabled] = enabled }
    }

    private inline fun <reified T : Enum<T>> enumValueOrDefault(raw: String?, fallback: T): T =
        runCatching { enumValueOf<T>(raw.orEmpty()) }.getOrDefault(fallback)
}
