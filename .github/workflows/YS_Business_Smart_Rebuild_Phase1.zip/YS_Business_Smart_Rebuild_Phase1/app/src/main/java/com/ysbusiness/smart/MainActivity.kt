package com.ysbusiness.smart

import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.ysbusiness.smart.data.AppPreferences
import com.ysbusiness.smart.ui.AppRoot

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val preferences = AppPreferences(applicationContext)
        setContent {
            AppRoot(
                preferences = preferences,
                onRequestBiometric = { onSuccess, onUnavailable ->
                    showBiometricPrompt(onSuccess, onUnavailable)
                }
            )
        }
    }

    private fun showBiometricPrompt(onSuccess: () -> Unit, onUnavailable: () -> Unit) {
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_WEAK
        val manager = BiometricManager.from(this)
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, "التحقق بالبصمة أو الوجه غير متاح", Toast.LENGTH_SHORT).show()
            onUnavailable()
            return
        }

        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    if (errorCode != BiometricPrompt.ERROR_USER_CANCELED && errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
                        Toast.makeText(this@MainActivity, errString, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )

        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("YS Business Smart")
                .setSubtitle("الدخول بالبصمة أو الوجه")
                .setAllowedAuthenticators(authenticators)
                .setNegativeButtonText("إلغاء")
                .build()
        )
    }
}
