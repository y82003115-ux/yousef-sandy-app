'use strict';

const STORAGE_KEY = 'ys_business_smart_v5';
const LEGACY_KEY = 'ys_business_mobile_v1';
const PASSWORD_ITERATIONS = 120000;
const PAYMENT_LABELS = {
  ar: { cash: 'نقدي', card: 'بطاقة', credit: 'آجل / دين' },
  ku: { cash: 'نەخت', card: 'کارت', credit: 'قەرز' },
  en: { cash: 'Cash', card: 'Card', credit: 'Credit' }
};
const ROLE_LABELS = {
  ar: { owner: 'المالك', manager: 'مدير', cashier: 'كاشير', inventory: 'مسؤول مخزن', accountant: 'محاسب' },
  ku: { owner: 'خاوەن', manager: 'بەڕێوەبەر', cashier: 'کاشێر', inventory: 'بەرپرسی کۆگا', accountant: 'ژمێریار' },
  en: { owner: 'Owner', manager: 'Manager', cashier: 'Cashier', inventory: 'Inventory', accountant: 'Accountant' }
};
const ROLE_ACCESS = {
  owner: ['*'],
  manager: ['dashboard','cashier','products','products:write','customers','customers:write','expenses','expenses:write','reports','pricing','settings'],
  cashier: ['dashboard','cashier','products','customers','customers:write'],
  inventory: ['dashboard','products','products:write','pricing'],
  accountant: ['dashboard','customers','expenses','expenses:write','reports']
};

const I18N = {
  ar: {
    auth_tagline:'إدارة ذكية وآمنة لأعمالك', setup_title:'إنشاء حساب المالك', setup_subtitle:'أول حساب يملك جميع الصلاحيات', full_name:'الاسم الكامل', store_name:'اسم المتجر', username:'اسم المستخدم', phone:'رقم الهاتف', email:'البريد الإلكتروني', password:'كلمة المرور', confirm_password:'تأكيد كلمة المرور', password_note:'استخدم 8 أحرف على الأقل مع رقم وحرف.', create_owner:'إنشاء الحساب وبدء التطبيق', login_title:'تسجيل الدخول', login_subtitle:'استخدم اسم المستخدم أو الهاتف أو البريد', login_identifier:'اسم المستخدم / الهاتف / البريد', remember_me:'تذكرني', forgot_password:'نسيت كلمة المرور؟', login_button:'دخول', secure_local:'تُحفظ البيانات مشفرة داخل الهاتف وتعمل دون إنترنت.', lock_app:'قفل التطبيق', logout:'تسجيل الخروج', dashboard_subtitle:'ملخص أعمالك اليوم', home_subtitle:'إدارة متجرك من الهاتف', today_sales:'مبيعات اليوم', invoices:'الفواتير', products:'المنتجات', low_stock:'مخزون منخفض', today_expenses:'مصاريف اليوم', smart_insights:'رؤى ذكية محلية', smart_insights_sub:'تحليل سريع يعمل دون إنترنت', quick_actions:'اختصارات سريعة', quick_actions_sub:'أكثر الإجراءات استخدامًا', new_sale:'بيع جديد', open_cashier:'فتح الكاشير', new_product:'منتج جديد', add_inventory:'إضافة للمخزون', smart_pricing:'تسعير ذكي', bulk_prices:'تعديل جماعي', reports:'التقارير', profits_sales:'الأرباح والمبيعات', recent_invoices:'آخر الفواتير', recent_sales:'أحدث عمليات البيع', cashier_subtitle:'بيع سريع وإدارة السلة', search_product:'ابحث باسم المنتج أو الباركود', cart:'السلة', inventory_subtitle:'إدارة المنتجات والكميات', search_inventory:'بحث في المنتجات', customers_subtitle:'العملاء والأرصدة والديون', search_customer:'بحث بالاسم أو الهاتف', more_subtitle:'المصاريف والتقارير والإعدادات', expenses:'المصاريف', expenses_sub:'تسجيل المصروفات اليومية', reports_sub:'المبيعات والأرباح', pricing_center:'مركز التسعير', pricing_center_sub:'تحديث الأسعار دفعة واحدة', accounts:'الحسابات والصلاحيات', accounts_sub:'إدارة الموظفين والدخول', settings:'الإعدادات', settings_sub:'المتجر واللغة والنسخ الاحتياطي', expenses_subtitle:'المصاريف التشغيلية', reports_subtitle:'تحليل أداء المتجر', today:'اليوم', this_month:'هذا الشهر', all:'الكل', total_sales:'إجمالي المبيعات', goods_cost:'تكلفة البضاعة', net_profit:'صافي الربح', top_selling:'الأكثر مبيعًا', by_quantity:'حسب عدد القطع', payment_methods:'طرق الدفع', invoice_distribution:'توزيع الفواتير', pricing_subtitle:'قواعد جماعية لتحديث الأسعار', price_engine:'محرك تحديث الأسعار', price_engine_sub:'غيّر قسمًا كاملًا مع معاينة وإمكانية التراجع', target_category:'القسم المستهدف', change_percent:'نسبة التغيير %', round_to:'تقريب إلى', price_basis:'أساس التحديث', current_price:'السعر الحالي', cost_plus_margin:'التكلفة + هامش الربح', profit_margin:'هامش الربح %', preview_changes:'معاينة التغييرات', apply_prices:'اعتماد الأسعار الجديدة', undo_last_pricing:'التراجع عن آخر تحديث أسعار', accounts_subtitle_page:'إدارة المستخدمين والصلاحيات', staff_accounts:'حسابات الموظفين', staff_accounts_sub:'صلاحية مستقلة لكل مستخدم', add_account:'إضافة حساب', security_title:'حماية تسجيل الدخول', security_body:'تشفير محلي، كلمات مرور مشتقة، وقفل مؤقت بعد المحاولات الفاشلة.', settings_subtitle_page:'إعدادات المتجر والبيانات', business_type:'نوع النشاط', language:'اللغة', currency:'العملة', low_stock_limit:'حد تنبيه المخزون', receipt_footer:'نص أسفل الفاتورة', save_settings:'حفظ الإعدادات', backup:'النسخ الاحتياطي', backup_sub:'احتفظ بنسخة من جميع البيانات', export_backup:'تصدير نسخة', import_backup:'استيراد نسخة', reset_all:'مسح بيانات النشاط التجاري', home:'الرئيسية', cashier:'الكاشير', inventory:'المخزون', customers:'العملاء', more:'المزيد', sale_invoice:'فاتورة البيع', complete_sale:'إتمام البيع', save:'حفظ', account_login_data:'بيانات الدخول والصلاحية', create_account:'إنشاء الحساب', add_to_cart:'إضافة إلى السلة', invoice_ready:'تم إنشاء الفاتورة', invoice_ready_sub:'يمكنك مشاركتها أو طباعتها'
  },
  ku: {
    auth_tagline:'بەڕێوەبردنی زیرەک و پارێزراوی کارەکانت', setup_title:'دروستکردنی هەژماری خاوەن', setup_subtitle:'یەکەم هەژمار هەموو دەسەڵاتەکانی هەیە', full_name:'ناوی تەواو', store_name:'ناوی فرۆشگا', username:'ناوی بەکارهێنەر', phone:'ژمارەی مۆبایل', email:'ئیمەیڵ', password:'وشەی نهێنی', confirm_password:'دووبارەکردنەوەی وشەی نهێنی', password_note:'لانیکەم ٨ پیت بە ژمارە و پیت بەکاربهێنە.', create_owner:'دروستکردنی هەژمار و دەستپێکردن', login_title:'چوونەژوورەوە', login_subtitle:'ناوی بەکارهێنەر، مۆبایل یان ئیمەیڵ بەکاربهێنە', login_identifier:'ناوی بەکارهێنەر / مۆبایل / ئیمەیڵ', remember_me:'لەسەر ئەم ئامێرە بمناسەوە', forgot_password:'وشەی نهێنیت لەبیرکردووە؟', login_button:'چوونەژوورەوەی پارێزراو', secure_local:'داتا بە شێوەی نهێنی لە مۆبایل هەڵدەگیرێت و بێ ئینتەرنێت کاردەکات.', lock_app:'داخستنی ئەپ', logout:'چوونەدەرەوە', dashboard_subtitle:'پوختەی کاری ئەمڕۆ', home_subtitle:'بەڕێوەبردنی فرۆشگا لە مۆبایل', today_sales:'فرۆشتنی ئەمڕۆ', invoices:'پسووڵەکان', products:'کاڵاکان', low_stock:'کۆگای کەم', today_expenses:'خەرجی ئەمڕۆ', smart_insights:'تێبینی زیرەکی ناوخۆیی', smart_insights_sub:'شیکردنەوەی خێرا بێ ئینتەرنێت', quick_actions:'کردارە خێراکان', quick_actions_sub:'زۆرترین کردارە بەکارهاتووەکان', new_sale:'فرۆشتنی نوێ', open_cashier:'کردنەوەی کاشێر', new_product:'کاڵای نوێ', add_inventory:'زیادکردن بۆ کۆگا', smart_pricing:'نرخدانانی زیرەک', bulk_prices:'گۆڕینی کۆمەڵەیی', reports:'ڕاپۆرتەکان', profits_sales:'قازانج و فرۆشتن', recent_invoices:'دوا پسووڵەکان', recent_sales:'دوا فرۆشتنەکان', cashier_subtitle:'فرۆشتنی خێرا و سەبەتە', search_product:'گەڕان بە ناو یان بارکۆد', cart:'سەبەتە', inventory_subtitle:'بەڕێوەبردنی کاڵا و بڕ', search_inventory:'گەڕان لە کاڵاکان', customers_subtitle:'کڕیار و قەرزەکان', search_customer:'گەڕان بە ناو یان مۆبایل', more_subtitle:'خەرجی و ڕاپۆرت و ڕێکخستن', expenses:'خەرجییەکان', reports_sub:'فرۆشتن و قازانج', pricing_center:'ناوەندی نرخدانان', accounts:'هەژمار و دەسەڵات', settings:'ڕێکخستنەکان', today:'ئەمڕۆ', this_month:'ئەم مانگە', all:'هەموو', total_sales:'کۆی فرۆشتن', goods_cost:'تێچووی کاڵا', net_profit:'قازانجی پاک', home:'سەرەکی', cashier:'کاشێر', inventory:'کۆگا', customers:'کڕیاران', more:'زیاتر', save:'پاشەکەوتکردن', add_to_cart:'زیادکردن بۆ سەبەتە', complete_sale:'تەواوکردنی فرۆشتن'
  },
  en: {
    auth_tagline:'Smart and secure business management', setup_title:'Create owner account', setup_subtitle:'The first account has full permissions', full_name:'Full name', store_name:'Store name', username:'Username', phone:'Phone number', email:'Email', password:'Password', confirm_password:'Confirm password', password_note:'Use at least 8 characters with a letter and a number.', create_owner:'Create account and start', login_title:'Sign in', login_subtitle:'Use username, phone, or email', login_identifier:'Username / phone / email', remember_me:'Remember me on this device', forgot_password:'Forgot password?', login_button:'Secure sign in', secure_local:'Data is encrypted on the phone and works offline.', lock_app:'Lock app', logout:'Sign out', dashboard_subtitle:'Today’s business summary', home_subtitle:'Manage your store from your phone', today_sales:'Today sales', invoices:'Invoices', products:'Products', low_stock:'Low stock', today_expenses:'Today expenses', smart_insights:'Local smart insights', smart_insights_sub:'Fast analysis that works offline', quick_actions:'Quick actions', quick_actions_sub:'Most used operations', new_sale:'New sale', open_cashier:'Open POS', new_product:'New product', add_inventory:'Add to inventory', smart_pricing:'Smart pricing', bulk_prices:'Bulk update', reports:'Reports', profits_sales:'Profit and sales', recent_invoices:'Recent invoices', recent_sales:'Latest sales', cashier_subtitle:'Fast selling and cart management', search_product:'Search product or barcode', cart:'Cart', inventory_subtitle:'Manage products and quantities', search_inventory:'Search inventory', customers_subtitle:'Customers, balances, and debts', search_customer:'Search name or phone', more_subtitle:'Expenses, reports, and settings', expenses:'Expenses', expenses_sub:'Record daily expenses', reports_sub:'Sales and profit', pricing_center:'Pricing center', pricing_center_sub:'Update prices in bulk', accounts:'Accounts and permissions', accounts_sub:'Manage staff and login', settings:'Settings', settings_sub:'Store, language, and backup', expenses_subtitle:'Operating expenses', reports_subtitle:'Business performance analysis', today:'Today', this_month:'This month', all:'All', total_sales:'Total sales', goods_cost:'Cost of goods', net_profit:'Net profit', top_selling:'Top selling', by_quantity:'By quantity', payment_methods:'Payment methods', invoice_distribution:'Invoice distribution', pricing_subtitle:'Bulk price update rules', price_engine:'Price update engine', price_engine_sub:'Change a whole category with preview and undo', target_category:'Target category', change_percent:'Change %', round_to:'Round to', price_basis:'Update basis', current_price:'Current price', cost_plus_margin:'Cost + margin', profit_margin:'Profit margin %', preview_changes:'Preview changes', apply_prices:'Apply new prices', undo_last_pricing:'Undo last price update', accounts_subtitle_page:'Manage users and permissions', staff_accounts:'Staff accounts', staff_accounts_sub:'Separate permission for each user', add_account:'Add account', security_title:'Login security', security_body:'Encrypted local storage, derived passwords, and temporary lock after failed attempts.', settings_subtitle_page:'Store and data settings', business_type:'Business type', language:'Language', currency:'Currency', low_stock_limit:'Low stock alert', receipt_footer:'Receipt footer', save_settings:'Save settings', backup:'Backup', backup_sub:'Keep a copy of your business data', export_backup:'Export backup', import_backup:'Import backup', reset_all:'Reset business data', home:'Home', cashier:'POS', inventory:'Inventory', customers:'Customers', more:'More', sale_invoice:'Sale invoice', complete_sale:'Complete sale', save:'Save', account_login_data:'Login details and permission', create_account:'Create account', add_to_cart:'Add to cart', invoice_ready:'Invoice created', invoice_ready_sub:'Share or print it'
  }
};
Object.assign(I18N.ar, { sales:'المبيعات', quick_glance:'نظرة سريعة', due_payments:'المدفوعات المستحقة', biometric_login:'أو تسجيل الدخول باستخدام', face:'الوجه', fingerprint:'بصمة', login_button:'دخول', create_owner:'إنشاء الحساب' });
Object.assign(I18N.ku, { sales:'فرۆشتن', quick_glance:'سەیرێکی خێرا', due_payments:'پارە پێویستەکان', biometric_login:'یان چوونەژوورەوە بە', face:'ڕووخسار', fingerprint:'پەنجەمۆر', login_button:'چوونەژوورەوە', create_owner:'دروستکردنی هەژمار' });
Object.assign(I18N.en, { sales:'Sales', quick_glance:'Quick glance', due_payments:'Due payments', biometric_login:'Or sign in with', face:'Face', fingerprint:'Fingerprint', login_button:'Sign in', create_owner:'Create account' });

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
let state;
let cart = [];
let selectedCategory = 'الكل';
let reportPeriod = 'month';
let currentReceiptText = '';
let toastTimer = null;
let currentDetailProductId = null;
let pricingDraft = [];

function seedState() {
  return {
    schemaVersion: 5,
    settings: { storeName: 'YS Business', currency: 'د.ع', lowStock: 5, receiptFooter: 'شكرًا لتسوقكم معنا', language: 'ar', theme: 'light', businessType: 'general' },
    security: { biometricUserId: null },
    users: [], session: null, auditLog: [], priceHistory: [],
    products: [
      { id:1, name:'قهوة تركية 250 غم', barcode:'6281234567890', category:'مشروبات', icon:'☕', price:6000, cost:4500, stock:48, minStock:5, description:'قهوة تركية بطحن ناعم.', unit:'علبة', size:'250 غم', color:'', image:'products/coffee.svg' },
      { id:2, name:'سكر أبيض 1 كغم', barcode:'6281234567891', category:'مواد غذائية', icon:'🧂', price:2000, cost:1500, stock:18, minStock:6, description:'سكر أبيض ناعم.', unit:'كيس', size:'1 كغم', color:'', image:'products/sugar.svg' },
      { id:3, name:'حليب كامل الدسم 1 لتر', barcode:'6281234567892', category:'مواد غذائية', icon:'🥛', price:2500, cost:1900, stock:12, minStock:5, description:'حليب كامل الدسم.', unit:'عبوة', size:'1 لتر', color:'', image:'products/milk.svg' },
      { id:4, name:'مياه معدنية 500 مل', barcode:'6281234567893', category:'مشروبات', icon:'🧴', price:500, cost:300, stock:80, minStock:12, description:'مياه معدنية معبأة.', unit:'قنينة', size:'500 مل', color:'', image:'products/water.svg' },
      { id:5, name:'شامبو شعر 400 مل', barcode:'6281234567894', category:'عناية شخصية', icon:'🧴', price:7000, cost:5200, stock:4, minStock:5, description:'شامبو للاستخدام اليومي.', unit:'عبوة', size:'400 مل', color:'', image:'products/shampoo.svg' },
      { id:6, name:'مسحوق غسيل 1 كغم', barcode:'6281234567895', category:'منظفات', icon:'🧼', price:5000, cost:3900, stock:25, minStock:5, description:'مسحوق غسيل للملابس.', unit:'كيس', size:'1 كغم', color:'', image:'products/detergent.svg' }
    ],
    customers: [{ id:1, name:'أحمد محمد', phone:'07XXXXXXXXX', notes:'', balance:0 }, { id:2, name:'سالم علي', phone:'07XXXXXXXXX', notes:'عميل دائم', balance:15000 }],
    expenses: [], invoices: []
  };
}

function normalizeState(data) {
  const base = seedState();
  const safe = data && typeof data === 'object' ? data : {};
  return {
    ...base, ...safe, schemaVersion: 5,
    settings: { ...base.settings, ...(safe.settings || {}) },
    security: { ...base.security, ...(safe.security || {}) },
    users: Array.isArray(safe.users) ? safe.users : [],
    session: safe.session || null,
    auditLog: Array.isArray(safe.auditLog) ? safe.auditLog : [],
    priceHistory: Array.isArray(safe.priceHistory) ? safe.priceHistory : [],
    products: Array.isArray(safe.products) ? safe.products.map(item => ({ description:'',unit:'',size:'',color:'',image:'',...item })) : base.products,
    customers: Array.isArray(safe.customers) ? safe.customers : [],
    expenses: Array.isArray(safe.expenses) ? safe.expenses : [],
    invoices: Array.isArray(safe.invoices) ? safe.invoices : []
  };
}

function readPersistedState() {
  try {
    let raw = '';
    if (window.Android?.loadSecureState) raw = window.Android.loadSecureState() || '';
    else raw = localStorage.getItem(STORAGE_KEY) || '';
    if (raw) return normalizeState(JSON.parse(raw));
    const legacy = localStorage.getItem(LEGACY_KEY);
    if (legacy) return normalizeState(JSON.parse(legacy));
  } catch (error) { console.error('Load state failed', error); }
  return seedState();
}

function saveState() {
  try {
    const raw = JSON.stringify(state);
    if (window.Android?.saveSecureState) window.Android.saveSecureState(raw);
    else localStorage.setItem(STORAGE_KEY, raw);
  } catch (error) { console.error('Save state failed', error); showToast('تعذر حفظ البيانات'); }
}

function nextId(list) { return list.reduce((max, item) => Math.max(max, Number(item.id) || 0), 0) + 1; }
function localDateKey(value = new Date()) { const date = value instanceof Date ? value : new Date(value); return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`; }
function currentLanguage() { return state?.settings?.language || 'ar'; }
function formatNumber(value) { return new Intl.NumberFormat(currentLanguage() === 'en' ? 'en-US' : 'ar-IQ', { maximumFractionDigits: 0 }).format(Number(value) || 0); }
function money(value) { return `${formatNumber(value)} ${state.settings.currency || 'د.ع'}`; }
function escapeHtml(value) { return String(value ?? '').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;'); }
function normalizeIdentifier(value) { return String(value || '').trim().toLowerCase().replace(/\s+/g,''); }
function randomHex(bytes = 16) { const arr = new Uint8Array(bytes); crypto.getRandomValues(arr); return [...arr].map(v => v.toString(16).padStart(2,'0')).join(''); }
function hexToBytes(hex) { return new Uint8Array(hex.match(/.{1,2}/g).map(byte => parseInt(byte,16))); }
function bytesToHex(buffer) { return [...new Uint8Array(buffer)].map(v => v.toString(16).padStart(2,'0')).join(''); }
async function passwordHash(password, salt) {
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name:'PBKDF2', salt:hexToBytes(salt), iterations:PASSWORD_ITERATIONS, hash:'SHA-256' }, material, 256);
  return bytesToHex(bits);
}
function passwordStrong(password) { return password.length >= 8 && /[A-Za-z\u0600-\u06FF]/.test(password) && /\d/.test(password); }
function currentUser() { return state.users.find(user => user.id === state.session?.userId) || null; }
function roleLabel(role) { return ROLE_LABELS[currentLanguage()]?.[role] || ROLE_LABELS.ar[role] || role; }
function hasAccess(permission) { const user = currentUser(); if (!user || user.active === false) return false; const access = ROLE_ACCESS[user.role] || []; return access.includes('*') || access.includes(permission); }
function audit(action, details = '') { const user = currentUser(); state.auditLog.push({ id:nextId(state.auditLog), at:new Date().toISOString(), userId:user?.id || null, userName:user?.fullName || 'System', action, details }); if (state.auditLog.length > 500) state.auditLog = state.auditLog.slice(-500); }

function t(key) { return I18N[currentLanguage()]?.[key] || I18N.ar[key] || key; }
function applyTheme(theme = state?.settings?.theme || 'light') {
  if (!['light','dark'].includes(theme)) theme = 'light';
  state.settings.theme = theme;
  document.documentElement.dataset.theme = theme;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = theme === 'dark' ? '#07172d' : '#ffffff';
  if (window.Android?.setSystemTheme) window.Android.setSystemTheme(theme);
  if (state.users.length) saveState();
}
function toggleTheme() { applyTheme((state.settings.theme || 'light') === 'dark' ? 'light' : 'dark'); }
function toggleLanguageMenu(force) {
  const menu = $('#languageMenu');
  const shouldShow = typeof force === 'boolean' ? force : menu.classList.contains('hidden');
  menu.classList.toggle('hidden', !shouldShow);
}
function applyLanguage(language = currentLanguage()) {
  if (!I18N[language]) language = 'ar';
  state.settings.language = language;
  document.documentElement.lang = language;
  document.documentElement.dir = language === 'en' ? 'ltr' : 'rtl';
  $$('[data-i18n]').forEach(node => { const value = I18N[language]?.[node.dataset.i18n] || I18N.ar[node.dataset.i18n]; if (value) node.textContent = value; });
  $$('[data-i18n-placeholder]').forEach(node => { const value = I18N[language]?.[node.dataset.i18nPlaceholder] || I18N.ar[node.dataset.i18nPlaceholder]; if (value) node.placeholder = value; });
  $$('#languageMenu button').forEach(button => button.classList.toggle('active', button.dataset.language === language));
  const activeView = $('.view.active');
  if (activeView && $('#pageTitle')) $('#pageTitle').textContent = t(activeView.dataset.titleKey || 'home');
  toggleLanguageMenu(false);
  if (state.users.length) saveState();
}

function showToast(message) { const toast = $('#toast'); if (!toast) return; toast.textContent = message; toast.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 2400); }
function emptyCard(title, body) { return `<div class="empty-card"><strong>${escapeHtml(title)}</strong><span>${escapeHtml(body)}</span></div>`; }

function showAuth(mode = 'login') {
  $('#app').classList.add('hidden'); $('#authScreen').classList.remove('hidden'); $('#profileMenu').classList.add('hidden');
  $('#firstRunPanel').classList.toggle('hidden', mode !== 'setup'); $('#loginPanel').classList.toggle('hidden', mode !== 'login');
}
function validSession() { const user = currentUser(); return Boolean(user && user.active !== false && state.session?.expiresAt > Date.now()); }
function enterApp() {
  const user = currentUser(); if (!user) return showAuth('login');
  $('#authScreen').classList.add('hidden'); $('#app').classList.remove('hidden');
  $('#profileName').textContent = user.fullName; $('#profileRole').textContent = roleLabel(user.role); $('#profileInitial').textContent = (user.fullName || 'Y').trim().charAt(0).toUpperCase(); $('#welcomeName').textContent = user.fullName;
  applyPermissions(); renderAll(); showView('dashboard', false); updateConnection();
}
function applyPermissions() {
  $$('[data-access]').forEach(node => node.classList.toggle('hidden', !hasAccess(node.dataset.access)));
  const preferred = ['dashboard','cashier','products','customers','more'].find(name => name === 'dashboard' || hasAccess(name));
  if (!$('.bottom-nav button:not(.hidden).active')) showView(preferred || 'dashboard');
}

async function handleSetup(event) {
  event.preventDefault(); const form = event.currentTarget; const data = Object.fromEntries(new FormData(form).entries());
  if (data.password !== data.confirmPassword) return showToast('كلمتا المرور غير متطابقتين');
  if (!passwordStrong(data.password)) return showToast(t('password_note'));
  if (!data.phone.trim() && !data.email.trim()) return showToast('أدخل رقم هاتف أو بريدًا إلكترونيًا');
  const salt = randomHex(); const hash = await passwordHash(data.password, salt);
  state.settings.storeName = data.storeName.trim();
  const user = { id:1, fullName:data.fullName.trim(), username:normalizeIdentifier(data.username), phone:normalizeIdentifier(data.phone), email:normalizeIdentifier(data.email), role:'owner', salt, passwordHash:hash, active:true, failedAttempts:0, lockedUntil:0, createdAt:new Date().toISOString() };
  state.users = [user]; state.security.biometricUserId = user.id; state.session = { userId:user.id, token:randomHex(24), expiresAt:Date.now()+30*24*60*60*1000, remember:true }; audit('owner_created', user.username); saveState(); enterApp(); showToast('تم إنشاء حساب المالك بنجاح');
}

async function handleLogin(event) {
  event.preventDefault(); const data = Object.fromEntries(new FormData(event.currentTarget).entries()); const identifier = normalizeIdentifier(data.identifier); const message = $('#loginMessage'); message.classList.add('hidden');
  const user = state.users.find(item => [item.username,item.phone,item.email].filter(Boolean).includes(identifier));
  if (!user || user.active === false) return loginError('بيانات الدخول غير صحيحة');
  if ((user.lockedUntil || 0) > Date.now()) return loginError(`الحساب مقفل مؤقتًا. حاول بعد ${Math.ceil((user.lockedUntil-Date.now())/60000)} دقيقة.`);
  const hash = await passwordHash(data.password, user.salt);
  if (hash !== user.passwordHash) {
    user.failedAttempts = (user.failedAttempts || 0) + 1;
    if (user.failedAttempts >= 5) { user.failedAttempts = 0; user.lockedUntil = Date.now()+5*60*1000; }
    saveState(); return loginError('بيانات الدخول غير صحيحة');
  }
  user.failedAttempts = 0; user.lockedUntil = 0; user.lastLoginAt = new Date().toISOString();
  const remember = data.remember === 'on'; state.session = { userId:user.id, token:randomHex(24), expiresAt:Date.now()+(remember ? 30*24*60*60*1000 : 12*60*60*1000), remember };
  if (remember) state.security.biometricUserId = user.id;
  audit('login', 'successful'); saveState(); enterApp();
}
function biometricLogin(method) {
  const user = state.users.find(item => item.id === state.security?.biometricUserId && item.active !== false);
  if (!user) return showToast('سجّل الدخول بكلمة المرور مرة واحدة ثم فعّل تذكرني');
  if (!window.Android?.authenticateBiometric) return showToast('الدخول الحيوي متاح داخل تطبيق أندرويد فقط');
  const title = method === 'face' ? (currentLanguage()==='en'?'Face sign in':currentLanguage()==='ku'?'چوونەژوورەوە بە ڕووخسار':'الدخول بالوجه') : (currentLanguage()==='en'?'Fingerprint sign in':currentLanguage()==='ku'?'چوونەژوورەوە بە پەنجەمۆر':'الدخول بالبصمة');
  window.Android.authenticateBiometric(method, title);
}
window.onBiometricResult = function(success, method, message) {
  if (!success) { if (message) showToast(message); return; }
  const user = state.users.find(item => item.id === state.security?.biometricUserId && item.active !== false);
  if (!user) return showToast('الحساب المحفوظ غير متاح');
  state.session = { userId:user.id, token:randomHex(24), expiresAt:Date.now()+30*24*60*60*1000, remember:true };
  user.lastLoginAt = new Date().toISOString(); audit('biometric_login', method); saveState(); enterApp();
};
function loginError(text) { const message = $('#loginMessage'); message.textContent = text; message.classList.remove('hidden'); }
function logout(lockOnly = false) { if (!lockOnly) { audit('logout'); state.security.biometricUserId = null; } state.session = null; saveState(); $('#loginForm').reset(); showAuth('login'); }

function showView(name, push = true) {
  if (name !== 'dashboard' && name !== 'more' && !hasAccess(name)) { showToast('لا تملك صلاحية فتح هذا القسم'); name = 'dashboard'; }
  const target = $(`#view-${name}`) || $('#view-dashboard'); $$('.view').forEach(view => view.classList.toggle('active', view === target));
  const mainNames = ['dashboard','cashier','products','customers','more']; const bottomActive = mainNames.includes(name) ? name : 'more'; $$('.bottom-nav button').forEach(button => button.classList.toggle('active', button.dataset.nav === bottomActive));
  if ($('#pageTitle')) $('#pageTitle').textContent = t(target.dataset.titleKey || 'home'); window.scrollTo({ top:0, behavior:'instant' });
  if (push && location.hash !== `#${name}`) history.pushState({view:name},'',`#${name}`);
  const renderers = { dashboard:renderDashboard, cashier:renderCashier, products:renderProducts, customers:renderCustomers, expenses:renderExpenses, reports:renderReports, pricing:renderPricing, accounts:renderAccounts, settings:renderSettings };
  renderers[name]?.();
}
function renderAll() { $('#storeNameHeader').textContent = state.settings.storeName; renderDashboard(); renderCashier(); renderProducts(); renderCustomers(); renderExpenses(); renderReports(); renderPricing(); renderAccounts(); renderSettings(); renderCart(); }

function renderDashboard() {
  const today = localDateKey();
  const todayInvoices = state.invoices.filter(item => localDateKey(item.createdAt) === today);
  const sales = todayInvoices.reduce((sum,item)=>sum+item.total,0);
  const soldQty = todayInvoices.reduce((sum,invoice)=>sum+invoice.items.reduce((x,item)=>x+item.qty,0),0);
  const lowStock = state.products.filter(product => product.stock <= product.minStock).length;
  const due = state.customers.reduce((sum,customer)=>sum+(Number(customer.balance)||0),0);
  $('#heroSales').textContent = money(sales);
  $('#heroInvoices').textContent = `${formatNumber(todayInvoices.length)} ${t('invoices')}`;
  $('#statSales').textContent = formatNumber(soldQty);
  $('#statInvoices').textContent = formatNumber(todayInvoices.length);
  $('#statCustomers').textContent = formatNumber(state.customers.length);
  $('#statProducts').textContent = formatNumber(state.products.length);
  $('#statLowStock').textContent = formatNumber(lowStock);
  $('#statExpenses').textContent = money(due);
  renderInsights();
  const recent = [...state.invoices].sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).slice(0,5);
  $('#recentInvoices').innerHTML = recent.length ? recent.map(invoice => `<article class="list-card"><div class="item-icon">🧾</div><div class="item-main"><strong>${escapeHtml(invoice.number)}</strong><small>${escapeHtml(invoice.customerName || 'عميل نقدي')}</small></div><div class="item-side"><strong>${money(invoice.total)}</strong><span class="badge ${invoice.paymentMethod==='credit'?'warn':'ok'}">${PAYMENT_LABELS[currentLanguage()][invoice.paymentMethod]}</span></div></article>`).join('') : '';
}
function renderInsights() {
  const since = Date.now()-30*24*60*60*1000; const sold = new Map(); state.invoices.filter(i=>new Date(i.createdAt).getTime()>=since).forEach(invoice=>invoice.items.forEach(item=>sold.set(item.productId,(sold.get(item.productId)||0)+item.qty)));
  const noSales = state.products.filter(p => !sold.get(p.id)); const low = state.products.filter(p=>p.stock<=p.minStock); const debt = state.customers.reduce((sum,c)=>sum+(Number(c.balance)||0),0); const avgMargin = state.products.length ? state.products.reduce((sum,p)=>sum+(p.price>0?(p.price-p.cost)/p.price*100:0),0)/state.products.length : 0;
  const insights = [
    {icon:'📉', title:noSales.length?`${noSales.length} منتجات ضعيفة الحركة`:'حركة المنتجات جيدة', body:noSales.length?`لم تُبع خلال آخر 30 يومًا: ${noSales.slice(0,2).map(p=>p.name).join('، ')}`:'كل المنتجات سجلت حركة خلال 30 يومًا.'},
    {icon:'⚠️', title:low.length?`${low.length} تنبيهات مخزون`:'المخزون مستقر', body:low.length?`الأكثر حاجة للطلب: ${low.slice(0,2).map(p=>p.name).join('، ')}`:'لا يوجد منتج تحت حد التنبيه.'},
    {icon:'💳', title:`ديون العملاء ${money(debt)}`, body:debt>0?'تابع الأرصدة وحدد مواعيد التحصيل.':'لا توجد ديون مستحقة حاليًا.'},
    {icon:'％', title:`متوسط هامش الربح ${formatNumber(avgMargin)}%`, body:avgMargin<15?'الهامش منخفض؛ راجع التكلفة والأسعار.':'الهامش الحالي ضمن مستوى مقبول مبدئيًا.'}
  ];
  $('#smartInsights').innerHTML = insights.map(item=>`<article class="insight-card"><span>${item.icon}</span><div><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.body)}</small></div></article>`).join('');
}

function productMedia(product) { return product.image ? `<img src="${product.image}" alt="${escapeHtml(product.name)}">` : escapeHtml(product.icon || '📦'); }
function renderCashier() {
  const categories = ['الكل',...new Set(state.products.map(p=>p.category))]; if (!categories.includes(selectedCategory)) selectedCategory='الكل';
  $('#categoryChips').innerHTML = categories.map(category=>`<button class="${category===selectedCategory?'active':''}" data-category="${escapeHtml(category)}">${escapeHtml(category)}</button>`).join('');
  const query = $('#cashierSearch')?.value.trim().toLowerCase() || ''; const products = state.products.filter(product => (selectedCategory==='الكل'||product.category===selectedCategory) && (!query||product.name.toLowerCase().includes(query)||product.barcode.toLowerCase().includes(query)));
  $('#cashierProducts').innerHTML = products.length ? products.map(product=>`<article class="product-card ${product.stock<=0?'disabled':''}"><button class="product-main" data-product-details="${product.id}"><span class="product-media">${productMedia(product)}</span><strong>${escapeHtml(product.name)}</strong><div class="price">${money(product.price)}</div><small>المتوفر: ${formatNumber(product.stock)}</small></button><button class="product-add" data-add-cart="${product.id}" ${product.stock<=0?'disabled':''}>＋</button></article>`).join('') : emptyCard('لا توجد نتائج','جرّب اسمًا أو تصنيفًا آخر.');
  renderCustomerOptions(); renderCart();
}
function openProductDetails(id) { const product = state.products.find(p=>p.id===Number(id)); if (!product) return; currentDetailProductId=product.id; $('#productDetailMedia').innerHTML=productMedia(product); $('#productDetailCategory').textContent=product.category; $('#productDetailName').textContent=product.name; $('#productDetailPrice').textContent=money(product.price); $('#productDetailDescription').textContent=product.description||'لا يوجد وصف إضافي.'; $('#productDetailMeta').innerHTML=[['الباركود',product.barcode],['المتوفر',formatNumber(product.stock)],['الوحدة',product.unit||'—'],['المقاس / الحجم',product.size||'—'],['اللون',product.color||'—'],['النشاط',state.settings.businessType]].map(([a,b])=>`<div><small>${escapeHtml(a)}</small><strong>${escapeHtml(b)}</strong></div>`).join(''); $('#detailAddCartBtn').classList.toggle('hidden',product.stock<=0||!hasAccess('cashier')); $('#productDialog').showModal(); }
function addToCart(productId) { const product=state.products.find(i=>i.id===Number(productId)); if(!product||product.stock<=0)return showToast('المنتج غير متوفر في المخزون'); const existing=cart.find(i=>i.productId===product.id); if(existing){if(existing.qty>=product.stock)return showToast('وصلت إلى الكمية المتوفرة');existing.qty+=1;}else cart.push({productId:product.id,qty:1}); renderCart(); showToast('تمت إضافة المنتج إلى السلة'); }
function changeQty(productId,delta){const item=cart.find(r=>r.productId===Number(productId));const product=state.products.find(r=>r.id===Number(productId));if(!item||!product)return;const next=item.qty+delta;if(next<=0)cart=cart.filter(r=>r!==item);else if(next<=product.stock)item.qty=next;else showToast('الكمية المطلوبة أكبر من المخزون');renderCart();}
function cartSummary(){const subtotal=cart.reduce((sum,item)=>{const p=state.products.find(r=>r.id===item.productId);return sum+(p?p.price*item.qty:0);},0);const discount=Math.max(0,Math.min(Number($('#discountInput')?.value)||0,subtotal));return{subtotal,discount,total:subtotal-discount};}
function renderCart(){const totalQty=cart.reduce((s,i)=>s+i.qty,0);const summary=cartSummary();$('#floatingCartCount').textContent=formatNumber(totalQty);$('#floatingCartTotal').textContent=money(summary.total);$('#openCartBtn').classList.toggle('show',totalQty>0);$('#cartItemsText').textContent=totalQty?`${formatNumber(totalQty)} قطعة`:'السلة فارغة';$('#cartItems').innerHTML=cart.length?cart.map(item=>{const p=state.products.find(r=>r.id===item.productId);if(!p)return'';return`<article class="cart-row"><span class="cart-icon">${p.image?`<img src="${p.image}" alt="">`:escapeHtml(p.icon||'📦')}</span><div class="cart-info"><strong>${escapeHtml(p.name)}</strong><small>${money(p.price*item.qty)}</small></div><div class="qty-control"><button data-qty="-1" data-product-id="${p.id}">−</button><b>${formatNumber(item.qty)}</b><button data-qty="1" data-product-id="${p.id}">＋</button></div></article>`;}).join(''):emptyCard('السلة فارغة','اضغط على علامة الزائد لإضافة منتج.');$('#subtotalValue').textContent=money(summary.subtotal);$('#discountValue').textContent=money(summary.discount);$('#totalValue').textContent=money(summary.total);}
function openCart(){ $('#sheetBackdrop').classList.remove('hidden');$('#cartSheet').classList.add('open');$('#cartSheet').setAttribute('aria-hidden','false'); }
function closeCart(){ $('#sheetBackdrop').classList.add('hidden');$('#cartSheet').classList.remove('open');$('#cartSheet').setAttribute('aria-hidden','true'); }
function renderCustomerOptions(){const select=$('#saleCustomer');if(!select)return;const current=select.value;select.innerHTML='<option value="">عميل نقدي</option>'+state.customers.map(c=>`<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('');if([...select.options].some(o=>o.value===current))select.value=current;}
function checkout(){if(!hasAccess('cashier'))return showToast('لا تملك صلاحية البيع');if(!cart.length)return showToast('السلة فارغة');const paymentMethod=$('#paymentMethod').value;const customerId=Number($('#saleCustomer').value)||null;const customer=state.customers.find(i=>i.id===customerId);if(paymentMethod==='credit'&&!customer)return showToast('اختر العميل للبيع الآجل');for(const item of cart){const p=state.products.find(r=>r.id===item.productId);if(!p||item.qty>p.stock)return showToast(`مخزون ${p?.name||'أحد المنتجات'} غير كافٍ`);}const{subtotal,discount,total}=cartSummary();const paid=paymentMethod==='credit'?Math.max(0,Math.min(Number($('#paidAmount').value)||0,total)):total;const debt=total-paid;const items=cart.map(item=>{const p=state.products.find(r=>r.id===item.productId);return{productId:p.id,name:p.name,qty:item.qty,price:p.price,cost:p.cost,total:p.price*item.qty,barcode:p.barcode};});items.forEach(item=>{state.products.find(p=>p.id===item.productId).stock-=item.qty;});if(customer&&debt>0)customer.balance=(Number(customer.balance)||0)+debt;const id=nextId(state.invoices);const invoice={id,number:`YS-${new Date().getFullYear()}-${String(id).padStart(6,'0')}`,createdAt:new Date().toISOString(),cashierId:currentUser().id,cashierName:currentUser().fullName,customerId,customerName:customer?.name||'عميل نقدي',paymentMethod,subtotal,discount,total,paid,debt,items};state.invoices.push(invoice);audit('sale_created',`${invoice.number} • ${total}`);saveState();cart=[];$('#discountInput').value='0';$('#paidAmount').value='0';closeCart();renderAll();showReceipt(invoice);}
function receiptText(invoice){const lines=[state.settings.storeName,'================================',`INVOICE  ${invoice.number}`,`DATE     ${new Date(invoice.createdAt).toLocaleString(currentLanguage()==='en'?'en-US':'ar-IQ')}`,`CASHIER  ${invoice.cashierName||''}`,`CUSTOMER ${invoice.customerName}`,'--------------------------------'];invoice.items.forEach(item=>lines.push(`${item.name}\n${formatNumber(item.qty)} × ${money(item.price)} = ${money(item.total)}`));lines.push('--------------------------------',`SUBTOTAL ${money(invoice.subtotal)}`,`DISCOUNT ${money(invoice.discount)}`,`TOTAL    ${money(invoice.total)}`,`PAYMENT  ${PAYMENT_LABELS[currentLanguage()][invoice.paymentMethod]}`);if(invoice.debt>0)lines.push(`DUE      ${money(invoice.debt)}`);lines.push('--------------------------------',`BARCODE: *${invoice.number.replace(/\D/g,'')}*`,state.settings.receiptFooter||'Thank you');return lines.join('\n');}
function showReceipt(invoice){currentReceiptText=receiptText(invoice);$('#receiptBody').textContent=currentReceiptText;$('#receiptDialog').showModal();}

function stockStatus(product){if(product.stock<=0)return{label:'نفد',cls:'danger'};if(product.stock<=product.minStock)return{label:'منخفض',cls:'warn'};return{label:'متوفر',cls:'ok'};}
function renderProducts(){const query=$('#productSearch')?.value.trim().toLowerCase()||'';const products=state.products.filter(p=>!query||p.name.toLowerCase().includes(query)||p.barcode.toLowerCase().includes(query));$('#productsList').innerHTML=products.length?products.map(p=>{const status=stockStatus(p);return`<article class="list-card"><div class="item-icon">${productMedia(p)}</div><div class="item-main"><strong>${escapeHtml(p.name)}</strong><small>${escapeHtml(p.category)} • ${escapeHtml(p.barcode)}</small><div class="action-row"><button class="mini-button" data-product-details="${p.id}">تفاصيل</button>${hasAccess('products:write')?`<button class="mini-button primary" data-edit-product="${p.id}">تعديل</button><button class="mini-button danger" data-delete-product="${p.id}">حذف</button>`:''}</div></div><div class="item-side"><strong>${money(p.price)}</strong><span class="badge ${status.cls}">${status.label}: ${formatNumber(p.stock)}</span></div></article>`;}).join(''):emptyCard('لا توجد منتجات','أضف أول منتج إلى مخزونك.');}
function renderCustomers(){const query=$('#customerSearch')?.value.trim().toLowerCase()||'';const customers=state.customers.filter(c=>!query||c.name.toLowerCase().includes(query)||String(c.phone||'').toLowerCase().includes(query));$('#customersList').innerHTML=customers.length?customers.map(c=>`<article class="list-card"><div class="item-icon">👤</div><div class="item-main"><strong>${escapeHtml(c.name)}</strong><small>${escapeHtml(c.phone||'لا يوجد رقم')} ${c.notes?`• ${escapeHtml(c.notes)}`:''}</small>${hasAccess('customers:write')?`<div class="action-row"><button class="mini-button primary" data-adjust-balance="${c.id}">تسوية الرصيد</button><button class="mini-button" data-edit-customer="${c.id}">تعديل</button><button class="mini-button danger" data-delete-customer="${c.id}">حذف</button></div>`:''}</div><div class="item-side"><strong>${money(c.balance||0)}</strong><span class="badge ${(c.balance||0)>0?'warn':'ok'}">${(c.balance||0)>0?'مدين':'مسدد'}</span></div></article>`).join(''):emptyCard('لا يوجد عملاء','أضف العملاء لمتابعة الديون والمبيعات الآجلة.');renderCustomerOptions();}
function renderExpenses(){const query=$('#expenseSearch')?.value.trim().toLowerCase()||'';const expenses=[...state.expenses].filter(e=>!query||e.title.toLowerCase().includes(query)||e.category.toLowerCase().includes(query)).sort((a,b)=>new Date(b.date)-new Date(a.date));$('#expensesList').innerHTML=expenses.length?expenses.map(e=>`<article class="list-card"><div class="item-icon">↘</div><div class="item-main"><strong>${escapeHtml(e.title)}</strong><small>${escapeHtml(e.category)} • ${new Date(e.date).toLocaleDateString('ar-IQ')}</small>${hasAccess('expenses:write')?`<div class="action-row"><button class="mini-button" data-edit-expense="${e.id}">تعديل</button><button class="mini-button danger" data-delete-expense="${e.id}">حذف</button></div>`:''}</div><div class="item-side"><strong>${money(e.amount)}</strong></div></article>`).join(''):emptyCard('لا توجد مصاريف','سجّل الإيجار والرواتب وبقية المصروفات.');}
function periodStart(period){const now=new Date();if(period==='today')return new Date(now.getFullYear(),now.getMonth(),now.getDate());if(period==='month')return new Date(now.getFullYear(),now.getMonth(),1);return new Date(0);}
function renderReports(){$$('#reportPeriod button').forEach(b=>b.classList.toggle('active',b.dataset.period===reportPeriod));const from=periodStart(reportPeriod);const invoices=state.invoices.filter(i=>new Date(i.createdAt)>=from);const expenses=state.expenses.filter(e=>new Date(e.date)>=from);const sales=invoices.reduce((s,i)=>s+i.total,0);const cost=invoices.reduce((s,i)=>s+i.items.reduce((x,item)=>x+item.cost*item.qty,0),0);const expenseTotal=expenses.reduce((s,e)=>s+e.amount,0);$('#reportSales').textContent=money(sales);$('#reportCost').textContent=money(cost);$('#reportExpenses').textContent=money(expenseTotal);$('#reportProfit').textContent=money(sales-cost-expenseTotal);const map=new Map();invoices.forEach(i=>i.items.forEach(item=>{const c=map.get(item.productId)||{name:item.name,qty:0,sales:0};c.qty+=item.qty;c.sales+=item.total;map.set(item.productId,c);}));const top=[...map.values()].sort((a,b)=>b.qty-a.qty).slice(0,5);$('#topProducts').innerHTML=top.length?top.map((item,index)=>`<div class="rank-row"><span class="rank">${index+1}</span><div><strong>${escapeHtml(item.name)}</strong><small>${formatNumber(item.qty)} قطعة</small></div><b>${money(item.sales)}</b></div>`).join(''):emptyCard('لا توجد مبيعات','ستظهر المنتجات الأعلى مبيعًا هنا.');const counts={cash:0,card:0,credit:0};invoices.forEach(i=>counts[i.paymentMethod]=(counts[i.paymentMethod]||0)+1);$('#paymentStats').innerHTML=Object.entries(counts).map(([key,count],index)=>`<div class="rank-row"><span class="rank">${index+1}</span><div><strong>${PAYMENT_LABELS[currentLanguage()][key]}</strong><small>${formatNumber(count)} فاتورة</small></div><b>${invoices.length?formatNumber(Math.round(count/invoices.length*100)):'0'}%</b></div>`).join('');}

function renderPricing(){const categories=['الكل',...new Set(state.products.map(p=>p.category))];const select=$('#pricingCategory');const current=select.value;select.innerHTML=categories.map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');if(categories.includes(current))select.value=current;$('#undoPricingBtn').classList.toggle('hidden',!state.priceHistory.length);}
function priceRound(value,increment){return Math.max(0,Math.round(value/increment)*increment);}
function previewPricing(){const category=$('#pricingCategory').value;const percent=Number($('#pricingPercent').value)||0;const rounding=Math.max(1,Number($('#pricingRounding').value)||1);const basis=$('#pricingBasis').value;const margin=Math.max(0,Number($('#pricingMargin').value)||0);pricingDraft=state.products.filter(p=>category==='الكل'||p.category===category).map(p=>{const raw=basis==='cost'?p.cost*(1+margin/100):p.price*(1+percent/100);return{id:p.id,name:p.name,oldPrice:p.price,newPrice:priceRound(raw,rounding)};}).filter(row=>row.newPrice!==row.oldPrice);$('#pricingPreview').innerHTML=pricingDraft.length?pricingDraft.map(row=>`<article class="list-card"><div class="item-icon">％</div><div class="item-main"><strong>${escapeHtml(row.name)}</strong><small>السعر القديم: ${money(row.oldPrice)}</small></div><div class="item-side"><span class="price-arrow">→</span><strong>${money(row.newPrice)}</strong></div></article>`).join(''):emptyCard('لا توجد تغييرات','عدّل النسبة أو اختر قسمًا آخر.');$('#applyPricingBtn').classList.toggle('hidden',!pricingDraft.length);}
function applyPricing(){if(!pricingDraft.length)return;const history={id:nextId(state.priceHistory),at:new Date().toISOString(),userId:currentUser().id,items:pricingDraft.map(row=>({id:row.id,oldPrice:row.oldPrice,newPrice:row.newPrice}))};state.priceHistory.push(history);pricingDraft.forEach(row=>{const p=state.products.find(x=>x.id===row.id);if(p)p.price=row.newPrice;});audit('bulk_price_update',`${pricingDraft.length} products`);pricingDraft=[];saveState();renderAll();$('#pricingPreview').innerHTML=emptyCard('تم تحديث الأسعار','يمكن التراجع عن آخر تحديث من الزر أدناه.');showToast('تم اعتماد الأسعار الجديدة');}
function undoPricing(){const history=state.priceHistory.pop();if(!history)return;history.items.forEach(row=>{const p=state.products.find(x=>x.id===row.id);if(p)p.price=row.oldPrice;});audit('bulk_price_undo',`${history.items.length} products`);saveState();renderAll();$('#pricingPreview').innerHTML=emptyCard('تم التراجع','عادت الأسعار إلى القيم السابقة.');showToast('تم التراجع عن آخر تحديث');}

function renderAccounts(){if(!hasAccess('accounts'))return;$('#accountsList').innerHTML=state.users.map(user=>`<article class="list-card"><div class="item-icon">${escapeHtml((user.fullName||'U').charAt(0))}</div><div class="item-main"><strong>${escapeHtml(user.fullName)}</strong><small>@${escapeHtml(user.username)} • ${escapeHtml(user.phone||user.email||'')}</small><div class="action-row">${user.role!=='owner'?`<button class="mini-button ${user.active===false?'primary':''}" data-toggle-user="${user.id}">${user.active===false?'تفعيل':'إيقاف'}</button><button class="mini-button" data-edit-account="${user.id}">تعديل / كلمة مرور</button><button class="mini-button danger" data-delete-user="${user.id}">حذف</button>`:'<span class="badge ok">الحساب الرئيسي</span>'}</div></div><div class="item-side"><strong>${roleLabel(user.role)}</strong><span class="badge ${user.active===false?'danger':'ok'}">${user.active===false?'موقوف':'نشط'}</span></div></article>`).join('');}
function openAccountDialog(user=null){const form=$('#accountForm');form.reset();form.dataset.id=user?.id||'';form.fullName.value=user?.fullName||'';form.username.value=user?.username||'';form.phone.value=user?.phone||'';form.email.value=user?.email||'';form.role.value=user?.role||'cashier';form.password.required=!user;form.password.placeholder=user?'اتركها فارغة دون تغيير':'8 أحرف على الأقل';$('#accountDialog').showModal();}
async function saveAccount(event){event.preventDefault();const form=event.currentTarget;const data=Object.fromEntries(new FormData(form).entries());const id=Number(form.dataset.id)||null;const username=normalizeIdentifier(data.username);const phone=normalizeIdentifier(data.phone);const email=normalizeIdentifier(data.email);const duplicate=state.users.find(u=>u.id!==id&&[username,phone,email].filter(Boolean).some(value=>[u.username,u.phone,u.email].includes(value)));if(duplicate)return showToast('اسم المستخدم أو الهاتف أو البريد مستخدم');let user=id?state.users.find(u=>u.id===id):null;if(!user){user={id:nextId(state.users),createdAt:new Date().toISOString(),active:true,failedAttempts:0,lockedUntil:0};state.users.push(user);}Object.assign(user,{fullName:data.fullName.trim(),username,phone,email,role:data.role});if(data.password){if(!passwordStrong(data.password))return showToast(t('password_note'));user.salt=randomHex();user.passwordHash=await passwordHash(data.password,user.salt);}audit(id?'account_updated':'account_created',user.username);saveState();$('#accountDialog').close();renderAccounts();showToast('تم حفظ الحساب');}

function renderSettings(){ $('#settingStoreName').value=state.settings.storeName;$('#settingCurrency').value=state.settings.currency;$('#settingLowStock').value=state.settings.lowStock;$('#settingReceiptFooter').value=state.settings.receiptFooter;$('#settingLanguage').value=state.settings.language;$('#settingBusinessType').value=state.settings.businessType; }
function businessCategories(){const type=state.settings.businessType; if(type==='clothing')return['رجالي','نسائي','أطفال','أحذية','إكسسوارات','أخرى'];if(type==='electronics')return['هواتف','حاسبات','إكسسوارات','أجهزة منزلية','أخرى'];if(type==='grocery')return['مشروبات','مواد غذائية','منظفات','عناية شخصية','أخرى'];return['عام','مشروبات','مواد غذائية','ملابس','إلكترونيات','أخرى'];}
function openDynamicForm(type,item=null){const dialog=$('#formDialog');const form=$('#dynamicForm');form.dataset.type=type;form.dataset.id=item?.id||'';form.dataset.image=item?.image||'';form.dataset.pendingImage='';dialog.classList.toggle('product-editor-modal',type==='product');if(type==='product'){const categories=[...new Set([...businessCategories(),...state.products.map(p=>p.category)])];$('#formTitle').textContent=item?'تعديل المنتج':'إضافة منتج';$('#formSubtitle').textContent='';const currentImage=item?.image||'';$('#formFields').innerHTML=`<label class="product-upload-box"><span id="productImagePreview">${currentImage?`<img src="${escapeHtml(currentImage)}" alt="">`:`<span class="upload-placeholder"><b>＋</b><strong>إضافة صورة</strong></span>`}</span><span class="camera-badge">▣</span><input name="imageFile" type="file" accept="image/*"></label><label>اسم المنتج<input name="name" required value="${escapeHtml(item?.name||'')}"></label><label>الباركود<input name="barcode" required inputmode="numeric" value="${escapeHtml(item?.barcode||'')}"></label><label>الفئة<select name="category">${categories.map(c=>`<option ${item?.category===c?'selected':''}>${escapeHtml(c)}</option>`).join('')}</select></label><label>الوصف<textarea name="description" rows="3">${escapeHtml(item?.description||'')}</textarea></label><div class="two-fields"><label>الوحدة<input name="unit" value="${escapeHtml(item?.unit||'قطعة')}"></label><label>الرمز<input name="icon" maxlength="8" value="${escapeHtml(item?.icon||'📦')}"></label></div><div class="two-fields"><label>المقاس / الحجم<input name="size" value="${escapeHtml(item?.size||'')}"></label><label>اللون<input name="color" value="${escapeHtml(item?.color||'')}"></label></div><div class="two-fields"><label>سعر البيع<input name="price" type="number" min="0" required value="${item?.price??0}"></label><label>تكلفة الشراء<input name="cost" type="number" min="0" required value="${item?.cost??0}"></label></div><div class="two-fields"><label>الكمية<input name="stock" type="number" min="0" required value="${item?.stock??0}"></label><label>حد التنبيه<input name="minStock" type="number" min="0" required value="${item?.minStock??state.settings.lowStock}"></label></div>`;}else if(type==='customer'){ $('#formTitle').textContent=item?'تعديل العميل':'إضافة عميل';$('#formSubtitle').textContent='بيانات العميل والتواصل';$('#formFields').innerHTML=`<label>اسم العميل<input name="name" required value="${escapeHtml(item?.name||'')}"></label><label>رقم الهاتف<input name="phone" inputmode="tel" value="${escapeHtml(item?.phone||'')}"></label><label>ملاحظات<textarea name="notes" rows="3">${escapeHtml(item?.notes||'')}</textarea></label>`;}else if(type==='balance'){ $('#formTitle').textContent='تسوية رصيد العميل';$('#formSubtitle').textContent=`الرصيد الحالي: ${money(item.balance||0)}`;$('#formFields').innerHTML=`<label>مبلغ التسوية<input name="amount" type="number" required placeholder="اكتب قيمة سالبة عند استلام دفعة"></label>`;}else if(type==='expense'){ $('#formTitle').textContent=item?'تعديل المصروف':'إضافة مصروف';$('#formSubtitle').textContent='المصاريف التشغيلية';$('#formFields').innerHTML=`<label>اسم المصروف<input name="title" required value="${escapeHtml(item?.title||'')}"></label><label>الفئة<select name="category">${['إيجار','رواتب','نقل','صيانة','كهرباء','تسويق','أخرى'].map(c=>`<option ${item?.category===c?'selected':''}>${c}</option>`).join('')}</select></label><label>المبلغ<input name="amount" type="number" min="0" required value="${item?.amount??0}"></label><label>التاريخ<input name="date" type="date" required value="${item?.date?localDateKey(item.date):localDateKey()}"></label><label>ملاحظات<textarea name="notes" rows="3">${escapeHtml(item?.notes||'')}</textarea></label>`;}dialog.showModal();}
async function compressImage(file){
  if(!file||!file.type.startsWith('image/'))return'';
  if(file.size>12*1024*1024)throw new Error('Image too large');
  const dataUrl=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file);});
  const image=await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=reject;img.src=dataUrl;});
  const max=1100;const scale=Math.min(1,max/Math.max(image.naturalWidth,image.naturalHeight));const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));canvas.getContext('2d').drawImage(image,0,0,canvas.width,canvas.height);return canvas.toDataURL('image/jpeg',.82);
}
async function saveDynamicForm(event){event.preventDefault();const form=event.currentTarget;const fd=new FormData(form);const data=Object.fromEntries(fd.entries());const id=Number(form.dataset.id)||null;if(form.dataset.type==='product'){const duplicate=state.products.find(p=>p.barcode===data.barcode.trim()&&p.id!==id);if(duplicate)return showToast('الباركود مستخدم لمنتج آخر');let image=form.dataset.image||'';const file=fd.get('imageFile');try{if(form.dataset.pendingImage)image=form.dataset.pendingImage;else if(file?.size)image=await compressImage(file);}catch(error){return showToast('تعذر معالجة الصورة أو حجمها كبير');}const record={id:id||nextId(state.products),name:data.name.trim(),barcode:data.barcode.trim(),category:data.category,icon:data.icon.trim()||'📦',description:data.description.trim(),unit:data.unit.trim(),size:data.size.trim(),color:data.color.trim(),image,price:Number(data.price)||0,cost:Number(data.cost)||0,stock:Number(data.stock)||0,minStock:Number(data.minStock)||0};if(id)state.products[state.products.findIndex(i=>i.id===id)]=record;else state.products.push(record);audit(id?'product_updated':'product_created',record.name);}if(form.dataset.type==='customer'){const existing=state.customers.find(i=>i.id===id);const record={id:id||nextId(state.customers),name:data.name.trim(),phone:data.phone.trim(),notes:data.notes.trim(),balance:existing?.balance||0};if(id)state.customers[state.customers.findIndex(i=>i.id===id)]=record;else state.customers.push(record);audit(id?'customer_updated':'customer_created',record.name);}if(form.dataset.type==='balance'){const customer=state.customers.find(i=>i.id===id);if(customer){customer.balance=Math.max(0,(Number(customer.balance)||0)+(Number(data.amount)||0));audit('customer_balance',customer.name);}}if(form.dataset.type==='expense'){const record={id:id||nextId(state.expenses),title:data.title.trim(),category:data.category,amount:Number(data.amount)||0,date:data.date,notes:data.notes.trim()};if(id)state.expenses[state.expenses.findIndex(i=>i.id===id)]=record;else state.expenses.push(record);audit(id?'expense_updated':'expense_created',record.title);}saveState();$('#formDialog').close();renderAll();showToast('تم حفظ البيانات');}
function deleteProduct(id){const used=state.invoices.some(i=>i.items.some(item=>item.productId===id));if(used)return showToast('لا يمكن حذف منتج مستخدم في فاتورة؛ اجعل كميته صفرًا');if(confirm('هل تريد حذف المنتج؟')){const p=state.products.find(i=>i.id===id);state.products=state.products.filter(i=>i.id!==id);cart=cart.filter(i=>i.productId!==id);audit('product_deleted',p?.name||id);saveState();renderAll();}}
function deleteCustomer(id){const c=state.customers.find(i=>i.id===id);if(!c)return;if((c.balance||0)>0)return showToast('سدّد رصيد العميل قبل الحذف');if(confirm('هل تريد حذف العميل؟')){state.customers=state.customers.filter(i=>i.id!==id);audit('customer_deleted',c.name);saveState();renderAll();}}
function deleteExpense(id){if(confirm('هل تريد حذف المصروف؟')){state.expenses=state.expenses.filter(i=>i.id!==id);audit('expense_deleted',id);saveState();renderAll();}}

function exportBackup(){const payload=JSON.stringify({app:'YS Business Smart',version:5,exportedAt:new Date().toISOString(),data:{settings:state.settings,products:state.products,customers:state.customers,expenses:state.expenses,invoices:state.invoices,priceHistory:state.priceHistory}},null,2);if(window.Android?.exportBackup)window.Android.exportBackup(payload);else{const blob=new Blob([payload],{type:'application/json'});const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download='ys-business-smart-backup.json';link.click();URL.revokeObjectURL(link.href);}}
function importBackupString(text){try{const parsed=JSON.parse(text);const data=parsed.data||parsed;if(!data||!Array.isArray(data.products)||!Array.isArray(data.invoices))throw new Error('Invalid');state={...state,settings:{...state.settings,...(data.settings||{})},products:data.products||[],customers:data.customers||[],expenses:data.expenses||[],invoices:data.invoices||[],priceHistory:data.priceHistory||[]};cart=[];audit('backup_imported');saveState();applyLanguage();renderAll();showToast('تم استيراد النسخة الاحتياطية');}catch(error){console.error(error);showToast('ملف النسخة الاحتياطية غير صالح');}}
window.receiveAndroidBackup=importBackupString;

function updateConnection(){const online=navigator.onLine;$('#onlineDot')?.classList.toggle('online',online);const badge=$('#connectionBadge');if(badge) badge.textContent=online?'● متصل بالإنترنت':'● دون إنترنت';}

function setupEvents(){
  document.addEventListener('click',event=>{
    const nav=event.target.closest('[data-nav]');if(nav)return showView(nav.dataset.nav);
    const action=event.target.closest('[data-action]');if(action){if(action.dataset.action==='add-product')openDynamicForm('product');if(action.dataset.action==='add-customer')openDynamicForm('customer');if(action.dataset.action==='add-expense')openDynamicForm('expense');return;}
    const category=event.target.closest('[data-category]');if(category){selectedCategory=category.dataset.category;renderCashier();return;}
    const detail=event.target.closest('[data-product-details]');if(detail){openProductDetails(detail.dataset.productDetails);return;}
    const addCart=event.target.closest('[data-add-cart]');if(addCart){addToCart(addCart.dataset.addCart);return;}
    const qty=event.target.closest('[data-qty]');if(qty){changeQty(qty.dataset.productId,Number(qty.dataset.qty));return;}
    const editProduct=event.target.closest('[data-edit-product]');if(editProduct){openDynamicForm('product',state.products.find(i=>i.id===Number(editProduct.dataset.editProduct)));return;}
    const delProduct=event.target.closest('[data-delete-product]');if(delProduct){deleteProduct(Number(delProduct.dataset.deleteProduct));return;}
    const editCustomer=event.target.closest('[data-edit-customer]');if(editCustomer){openDynamicForm('customer',state.customers.find(i=>i.id===Number(editCustomer.dataset.editCustomer)));return;}
    const adjust=event.target.closest('[data-adjust-balance]');if(adjust){openDynamicForm('balance',state.customers.find(i=>i.id===Number(adjust.dataset.adjustBalance)));return;}
    const delCustomer=event.target.closest('[data-delete-customer]');if(delCustomer){deleteCustomer(Number(delCustomer.dataset.deleteCustomer));return;}
    const editExpense=event.target.closest('[data-edit-expense]');if(editExpense){openDynamicForm('expense',state.expenses.find(i=>i.id===Number(editExpense.dataset.editExpense)));return;}
    const delExpense=event.target.closest('[data-delete-expense]');if(delExpense){deleteExpense(Number(delExpense.dataset.deleteExpense));return;}
    const period=event.target.closest('[data-period]');if(period){reportPeriod=period.dataset.period;renderReports();return;}
    const language=event.target.closest('[data-language]');if(language){applyLanguage(language.dataset.language);return;}
    const biometric=event.target.closest('[data-biometric]');if(biometric){biometricLogin(biometric.dataset.biometric);return;}
    const toggleUser=event.target.closest('[data-toggle-user]');if(toggleUser){const u=state.users.find(x=>x.id===Number(toggleUser.dataset.toggleUser));if(u){u.active=u.active===false;u.lockedUntil=0;audit('account_status',`${u.username}:${u.active}`);saveState();renderAccounts();}return;}
    const editAccount=event.target.closest('[data-edit-account]');if(editAccount){openAccountDialog(state.users.find(x=>x.id===Number(editAccount.dataset.editAccount)));return;}
    const delUser=event.target.closest('[data-delete-user]');if(delUser){const u=state.users.find(x=>x.id===Number(delUser.dataset.deleteUser));if(u&&confirm(`حذف حساب ${u.fullName}؟`)){state.users=state.users.filter(x=>x.id!==u.id);audit('account_deleted',u.username);saveState();renderAccounts();}return;}
    if(event.target.closest('[data-close-dialog]'))$('#formDialog').close();if(event.target.closest('[data-close-account]'))$('#accountDialog').close();if(event.target.closest('[data-close-receipt]'))$('#receiptDialog').close();if(event.target.closest('[data-close-product]'))$('#productDialog').close();
  });
  $$('.password-toggle').forEach(button=>button.addEventListener('click',()=>{const input=button.parentElement.querySelector('input');input.type=input.type==='password'?'text':'password';}));
  $('#authLanguageButton').addEventListener('click',event=>{event.stopPropagation();toggleLanguageMenu();});$('#appLanguageButton').addEventListener('click',event=>{event.stopPropagation();toggleLanguageMenu();});$('#authThemeToggle').addEventListener('click',toggleTheme);$('#appThemeToggle').addEventListener('click',toggleTheme);document.addEventListener('click',event=>{if(!event.target.closest('#languageMenu')&&!event.target.closest('#authLanguageButton')&&!event.target.closest('#appLanguageButton'))toggleLanguageMenu(false);});
  $('#dynamicForm').addEventListener('change',async event=>{const input=event.target.closest('input[name="imageFile"]');if(!input?.files?.[0])return;try{const preview=await compressImage(input.files[0]);$('#dynamicForm').dataset.pendingImage=preview;const target=$('#productImagePreview');if(target)target.innerHTML=`<img src="${preview}" alt="">`;}catch(error){showToast('تعذر قراءة الصورة');}});
  $('#setupForm').addEventListener('submit',handleSetup);$('#loginForm').addEventListener('submit',handleLogin);$('#forgotPasswordBtn').addEventListener('click',()=>showToast('يمكن للمالك إعادة كلمة مرور الموظف من قسم الحسابات.'));
  $('#profileButton').addEventListener('click',()=>$('#profileMenu').classList.toggle('hidden'));$('#lockAppBtn').addEventListener('click',()=>logout(true));$('#logoutBtn').addEventListener('click',()=>logout(false));
  $('#cashierSearch').addEventListener('input',renderCashier);$('#productSearch').addEventListener('input',renderProducts);$('#customerSearch').addEventListener('input',renderCustomers);$('#expenseSearch').addEventListener('input',renderExpenses);$('#discountInput').addEventListener('input',renderCart);$('#paymentMethod').addEventListener('change',()=>$('#paidAmountWrap').classList.toggle('hidden',$('#paymentMethod').value!=='credit'));$('#openCartBtn').addEventListener('click',openCart);$('#closeCartBtn').addEventListener('click',closeCart);$('#sheetBackdrop').addEventListener('click',closeCart);$('#checkoutBtn').addEventListener('click',checkout);$('#dynamicForm').addEventListener('submit',saveDynamicForm);$('#accountForm').addEventListener('submit',saveAccount);$('#addAccountBtn').addEventListener('click',()=>openAccountDialog());
  $('#detailAddCartBtn').addEventListener('click',()=>{addToCart(currentDetailProductId);$('#productDialog').close();});
  $('#pricingBasis').addEventListener('change',()=>$('#marginWrap').classList.toggle('hidden',$('#pricingBasis').value!=='cost'));$('#previewPricingBtn').addEventListener('click',previewPricing);$('#applyPricingBtn').addEventListener('click',applyPricing);$('#undoPricingBtn').addEventListener('click',undoPricing);
  $('#settingsForm').addEventListener('submit',event=>{event.preventDefault();state.settings.storeName=$('#settingStoreName').value.trim()||'YS Business';state.settings.currency=$('#settingCurrency').value.trim()||'د.ع';state.settings.lowStock=Math.max(0,Number($('#settingLowStock').value)||0);state.settings.receiptFooter=$('#settingReceiptFooter').value.trim();state.settings.businessType=$('#settingBusinessType').value;state.settings.language=$('#settingLanguage').value;audit('settings_updated');saveState();applyLanguage();renderAll();showToast('تم حفظ الإعدادات');});
  $('#exportBackupBtn').addEventListener('click',exportBackup);$('#importBackupBtn').addEventListener('click',()=>{if(window.Android?.importBackup)window.Android.importBackup();else{const input=document.createElement('input');input.type='file';input.accept='application/json';input.onchange=async()=>input.files?.[0]&&importBackupString(await input.files[0].text());input.click();}});
  $('#resetAppBtn').addEventListener('click',()=>{if(!confirm('سيتم حذف المنتجات والفواتير والعملاء والمصاريف مع الإبقاء على حسابات الدخول. هل أنت متأكد؟'))return;const clean=seedState();state.products=clean.products;state.customers=[];state.expenses=[];state.invoices=[];state.priceHistory=[];audit('business_data_reset');saveState();renderAll();showView('dashboard');showToast('تمت إعادة ضبط بيانات النشاط');});
  $('#shareReceiptBtn').addEventListener('click',async()=>{if(window.Android?.shareText)window.Android.shareText('YS Business Invoice',currentReceiptText);else if(navigator.share)await navigator.share({title:'YS Business Invoice',text:currentReceiptText});else{await navigator.clipboard.writeText(currentReceiptText);showToast('تم نسخ الفاتورة');}});$('#printReceiptBtn').addEventListener('click',()=>window.Android?.printPage?window.Android.printPage('YS Business Invoice'):window.print());
  window.addEventListener('popstate',()=>showView(location.hash.replace('#','')||'dashboard',false));window.addEventListener('online',updateConnection);window.addEventListener('offline',updateConnection);
}

async function init(){state=readPersistedState();setupEvents();applyTheme(state.settings.theme);applyLanguage(state.settings.language);if(!state.users.length){saveState();showAuth('setup');return;}if(validSession())enterApp();else{state.session=null;saveState();showAuth('login');}}
document.addEventListener('DOMContentLoaded',()=>{init().catch(error=>{console.error(error);showToast('تعذر تشغيل التطبيق بأمان');showAuth(state?.users?.length?'login':'setup');});});
