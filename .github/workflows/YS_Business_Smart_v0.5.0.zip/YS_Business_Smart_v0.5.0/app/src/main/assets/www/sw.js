const CACHE = 'ys-business-smart-v5';
const ASSETS = ['./','./index.html','./styles.css','./app.js','./manifest.webmanifest','./logo.svg','./products/coffee.svg','./products/sugar.svg','./products/milk.svg','./products/water.svg','./products/shampoo.svg','./products/detergent.svg'];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS))));
self.addEventListener('activate', event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))));
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
    const copy = response.clone(); caches.open(CACHE).then(cache => cache.put(event.request, copy)); return response;
  }).catch(() => caches.match('./index.html'))));
});
