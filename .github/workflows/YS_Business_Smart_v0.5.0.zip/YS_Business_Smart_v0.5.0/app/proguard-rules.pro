-keepclassmembers class com.ysbusiness.mobile.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
