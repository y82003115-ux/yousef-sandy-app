package com.ysbusiness.smart.security

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PasswordHasherTest {
    @Test
    fun correctPasswordVerifiesAndWrongPasswordFails() {
        val result = PasswordHasher.hash("StrongPass123".toCharArray())
        assertTrue(PasswordHasher.verify("StrongPass123".toCharArray(), result.saltBase64, result.hashBase64))
        assertFalse(PasswordHasher.verify("WrongPass123".toCharArray(), result.saltBase64, result.hashBase64))
    }
}
