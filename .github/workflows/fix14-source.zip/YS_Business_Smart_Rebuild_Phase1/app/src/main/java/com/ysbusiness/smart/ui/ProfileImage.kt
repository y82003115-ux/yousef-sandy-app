package com.ysbusiness.smart.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.ysbusiness.smart.ui.theme.Pink
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

fun saveProfileBitmap(context: Context, bitmap: Bitmap): String {
    val directory = File(context.filesDir, "profile").apply { mkdirs() }
    val file = File(directory, "owner_profile.jpg")
    FileOutputStream(file).use { output ->
        bitmap.compress(Bitmap.CompressFormat.JPEG, 94, output)
    }
    return Uri.fromFile(file).toString()
}

fun saveStoreLogoBitmap(context: Context, bitmap: Bitmap): String {
    val directory = File(context.filesDir, "branding").apply { mkdirs() }
    val file = File(directory, "store_logo.jpg")
    FileOutputStream(file).use { output ->
        bitmap.compress(Bitmap.CompressFormat.JPEG, 94, output)
    }
    return Uri.fromFile(file).toString()
}

suspend fun loadProfileBitmap(context: Context, uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
    runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val width = info.size.width
                val height = info.size.height
                val longest = max(width, height)
                if (longest > 2400) {
                    val ratio = 2400f / longest.toFloat()
                    decoder.setTargetSize(
                        (width * ratio).roundToInt().coerceAtLeast(1),
                        (height * ratio).roundToInt().coerceAtLeast(1)
                    )
                }
            }
        } else {
            context.contentResolver.openInputStream(uri)?.use { input -> BitmapFactory.decodeStream(input) }
        }
    }.getOrNull()
}

private fun cropProfileBitmap(
    source: Bitmap,
    zoom: Float,
    offset: Offset,
    viewport: IntSize
): Bitmap {
    if (viewport.width <= 0 || viewport.height <= 0) {
        val size = min(source.width, source.height)
        val left = (source.width - size) / 2
        val top = (source.height - size) / 2
        return Bitmap.createScaledBitmap(
            Bitmap.createBitmap(source, left, top, size, size),
            1024,
            1024,
            true
        )
    }

    val viewportWidth = viewport.width.toFloat()
    val viewportHeight = viewport.height.toFloat()
    val baseScale = max(
        viewportWidth / source.width.toFloat(),
        viewportHeight / source.height.toFloat()
    )
    val totalScale = baseScale * zoom.coerceAtLeast(1f)
    val cropWidth = (viewportWidth / totalScale).coerceAtMost(source.width.toFloat())
    val cropHeight = (viewportHeight / totalScale).coerceAtMost(source.height.toFloat())

    val centerX = source.width / 2f - offset.x / totalScale
    val centerY = source.height / 2f - offset.y / totalScale
    val left = (centerX - cropWidth / 2f)
        .coerceIn(0f, (source.width - cropWidth).coerceAtLeast(0f))
    val top = (centerY - cropHeight / 2f)
        .coerceIn(0f, (source.height - cropHeight).coerceAtLeast(0f))

    val x = left.roundToInt().coerceIn(0, source.width - 1)
    val y = top.roundToInt().coerceIn(0, source.height - 1)
    val width = cropWidth.roundToInt().coerceIn(1, source.width - x)
    val height = cropHeight.roundToInt().coerceIn(1, source.height - y)
    val square = min(width, height)
    val adjustedX = (x + (width - square) / 2).coerceIn(0, source.width - square)
    val adjustedY = (y + (height - square) / 2).coerceIn(0, source.height - square)

    val cropped = Bitmap.createBitmap(source, adjustedX, adjustedY, square, square)
    return Bitmap.createScaledBitmap(cropped, 1024, 1024, true)
}

@Composable
fun ProfileCropDialog(
    source: Bitmap,
    s: S,
    onDismiss: () -> Unit,
    onSave: (Bitmap) -> Unit
) {
    var zoom by remember(source) { mutableFloatStateOf(1f) }
    var offset by remember(source) { mutableStateOf(Offset.Zero) }
    var viewport by remember(source) { mutableStateOf(IntSize.Zero) }

    fun clampOffset(candidate: Offset, candidateZoom: Float): Offset {
        if (viewport.width == 0 || viewport.height == 0) return Offset.Zero
        val baseScale = max(
            viewport.width / source.width.toFloat(),
            viewport.height / source.height.toFloat()
        )
        val displayedWidth = source.width * baseScale * candidateZoom
        val displayedHeight = source.height * baseScale * candidateZoom
        val maxX = max(0f, (displayedWidth - viewport.width) / 2f)
        val maxY = max(0f, (displayedHeight - viewport.height) / 2f)
        return Offset(
            candidate.x.coerceIn(-maxX, maxX),
            candidate.y.coerceIn(-maxY, maxY)
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(.94f)
                .wrapContentHeight(),
            shape = RoundedCornerShape(30.dp),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 24.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .35f))
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(310.dp)
                        .onSizeChanged { viewport = it }
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .pointerInput(source, viewport) {
                            detectTransformGestures { _, pan, gestureZoom, _ ->
                                val newZoom = (zoom * gestureZoom).coerceIn(1f, 5f)
                                zoom = newZoom
                                offset = clampOffset(offset + pan, newZoom)
                            }
                        }
                        .border(4.dp, Pink, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    val sourceImage = remember(source) { source.asImageBitmap() }
                    Canvas(modifier = Modifier.matchParentSize()) {
                        val baseScale = max(
                            size.width / source.width.toFloat(),
                            size.height / source.height.toFloat()
                        )
                        val totalScale = baseScale * zoom
                        val drawWidth = source.width * totalScale
                        val drawHeight = source.height * totalScale
                        val left = (size.width - drawWidth) / 2f + offset.x
                        val top = (size.height - drawHeight) / 2f + offset.y
                        drawImage(
                            image = sourceImage,
                            srcOffset = IntOffset.Zero,
                            srcSize = IntSize(source.width, source.height),
                            dstOffset = IntOffset(left.roundToInt(), top.roundToInt()),
                            dstSize = IntSize(
                                drawWidth.roundToInt().coerceAtLeast(1),
                                drawHeight.roundToInt().coerceAtLeast(1)
                            )
                        )
                    }
                    Box(
                        Modifier
                            .matchParentSize()
                            .border(1.dp, Color.White.copy(alpha = .42f), CircleShape)
                    )
                }
                Spacer(Modifier.height(22.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f).height(54.dp),
                        shape = RoundedCornerShape(17.dp),
                        border = BorderStroke(1.3.dp, Pink.copy(alpha = .65f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Pink)
                    ) {
                        Text(s.cancel, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { onSave(cropProfileBitmap(source, zoom, offset, viewport)) },
                        modifier = Modifier.weight(1f).height(54.dp),
                        shape = RoundedCornerShape(17.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Pink)
                    ) {
                        Text(s.savePhoto, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileAvatar(
    imageUri: String,
    size: Dp,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(initialValue = null, key1 = imageUri) {
        value = if (imageUri.isBlank()) null else withContext(Dispatchers.IO) {
            runCatching {
                val uri = Uri.parse(imageUri)
                val decoded = when (uri.scheme) {
                    "file" -> BitmapFactory.decodeFile(uri.path)
                    else -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri))
                    } else {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            BitmapFactory.decodeStream(input)
                        }
                    }
                }
                decoded?.asImageBitmap()
            }.getOrNull()
        }
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surface)
            .border(2.dp, Pink, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize()
            )
        } else {
            Icon(
                imageVector = Icons.Rounded.Person,
                contentDescription = null,
                tint = Pink,
                modifier = Modifier.size(size * 0.5f)
            )
        }
    }
}

@Composable
fun StoreLogoAvatar(
    imageUri: String,
    size: Dp,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(initialValue = null, key1 = imageUri) {
        value = if (imageUri.isBlank()) null else withContext(Dispatchers.IO) {
            runCatching {
                val uri = Uri.parse(imageUri)
                val decoded = when (uri.scheme) {
                    "file" -> BitmapFactory.decodeFile(uri.path)
                    else -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri))
                    } else {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            BitmapFactory.decodeStream(input)
                        }
                    }
                }
                decoded?.asImageBitmap()
            }.getOrNull()
        }
    }

    val shape = RoundedCornerShape(size * 0.28f)
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(
                androidx.compose.ui.graphics.Brush.linearGradient(
                    listOf(Color(0xFF6D28D9), Pink, Color(0xFF06B6D4))
                )
            )
            .padding(2.dp)
            .clip(shape)
            .background(Color(0xFF070A2A)),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize()
            )
        } else {
            Icon(
                imageVector = Icons.Rounded.Storefront,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(size * 0.48f)
            )
        }
    }
}

