package com.ysbusiness.smart.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ysbusiness.smart.ui.theme.Pink
import com.ysbusiness.smart.ui.theme.PinkLight

@Composable
fun PinkButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null
) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier = modifier
            .height(58.dp)
            .background(
                brush = if (enabled) Brush.horizontalGradient(listOf(PinkLight, Pink))
                else Brush.horizontalGradient(listOf(Color.Gray, Color.DarkGray)),
                shape = shape
            )
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Text(text, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (icon != null) {
                Spacer(Modifier.width(10.dp))
                Icon(icon, null, tint = Color.White)
            }
        }
    }
}

@Composable
fun SelectableTile(
    title: String,
    icon: ImageVector,
    accent: Color,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(22.dp)
    val container = if (selected) {
        Brush.linearGradient(
            listOf(
                accent.copy(alpha = .94f),
                accent.copy(alpha = .72f)
            )
        )
    } else {
        Brush.linearGradient(
            listOf(
                MaterialTheme.colorScheme.surface,
                accent.copy(alpha = .10f)
            )
        )
    }

    Box(
        modifier = modifier
            .height(128.dp)
            .clip(shape)
            .background(container)
            .border(
                width = if (selected) 2.dp else 1.2.dp,
                color = accent.copy(alpha = if (selected) .95f else .58f),
                shape = shape
            )
            .clickable(onClick = onClick)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(
                        if (selected) Color.White.copy(alpha = .17f)
                        else accent.copy(alpha = .14f),
                        RoundedCornerShape(18.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    icon,
                    null,
                    tint = if (selected) Color.White else accent,
                    modifier = Modifier.size(34.dp)
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(
                title,
                fontWeight = FontWeight.Black,
                fontSize = 17.sp,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
            )
        }

        if (selected) {
            Surface(
                modifier = Modifier.align(Alignment.TopStart),
                shape = RoundedCornerShape(50),
                color = Color.White
            ) {
                Icon(
                    Icons.Rounded.Check,
                    null,
                    tint = accent,
                    modifier = Modifier.padding(5.dp).size(16.dp)
                )
            }
        }
    }
}

@Composable
fun CurrencyCard(
    code: String,
    symbol: String,
    name: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(24.dp)
    Surface(
        modifier = modifier
            .height(112.dp)
            .clickable(onClick = onClick),
        shape = shape,
        color = Color.Transparent,
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) PinkLight else MaterialTheme.colorScheme.outline.copy(alpha = .45f)
        ),
        shadowElevation = if (selected) 10.dp else 2.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    if (selected) Brush.linearGradient(listOf(PinkLight, Pink))
                    else Brush.linearGradient(
                        listOf(
                            MaterialTheme.colorScheme.surface,
                            MaterialTheme.colorScheme.surface.copy(alpha = .92f)
                        )
                    )
                )
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = if (selected) Color.White.copy(alpha = .18f) else Pink.copy(alpha = .10f),
                    border = BorderStroke(1.dp, if (selected) Color.White.copy(alpha = .25f) else Pink.copy(alpha = .18f))
                ) {
                    Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
                        Text(
                            symbol,
                            color = if (selected) Color.White else Pink,
                            fontWeight = FontWeight.Black,
                            fontSize = 23.sp
                        )
                    }
                }
                Column(
                    modifier = Modifier.weight(1f).padding(horizontal = 10.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        code,
                        color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Black,
                        fontSize = 21.sp
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        name,
                        color = if (selected) Color.White.copy(alpha = .82f)
                        else MaterialTheme.colorScheme.onSurface.copy(alpha = .62f),
                        fontSize = 12.sp,
                        maxLines = 1
                    )
                }
            }
            Surface(
                modifier = Modifier.align(Alignment.TopStart),
                shape = RoundedCornerShape(50),
                color = if (selected) Color.White else Color.Transparent,
                border = BorderStroke(1.dp, if (selected) Color.White else MaterialTheme.colorScheme.outline.copy(alpha = .45f))
            ) {
                Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
                    if (selected) Icon(Icons.Rounded.Check, null, tint = Pink, modifier = Modifier.size(17.dp))
                }
            }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.fillMaxWidth())
}

@Composable
fun YSLogo(size: Int = 92) {
    Box(
        modifier = Modifier
            .size(size.dp)
            .background(Brush.linearGradient(listOf(PinkLight, Pink)), RoundedCornerShape(24.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text("YS", color = Color.White, fontWeight = FontWeight.Black, fontSize = (size * .38).sp)
    }
}
