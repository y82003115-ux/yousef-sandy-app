package com.ysbusiness.smart.security

import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object PasswordHasher {
    private const val ITERATIONS = 120_000
    private const val KEY_LENGTH_BITS = 256

    data class HashResult(val saltBase64: String, val hashBase64: String)

    fun hash(password: CharArray): HashResult {
        require(password.isNotEmpty()) { "Password must not be empty" }
        val salt = ByteArray(16).also(SecureRandom()::nextBytes)
        return HashResult(
            saltBase64 = salt.toHex(),
            hashBase64 = derive(password, salt).toHex()
        )
    }

    fun verify(password: CharArray, saltBase64: String, expectedHashBase64: String): Boolean {
        if (password.isEmpty() || saltBase64.isBlank() || expectedHashBase64.isBlank()) return false
        val salt = saltBase64.hexToBytes() ?: return false
        val expected = expectedHashBase64.hexToBytes() ?: return false
        val actual = derive(password, salt)
        return constantTimeEquals(actual, expected)
    }

    private fun derive(password: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password, salt, ITERATIONS, KEY_LENGTH_BITS)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
            password.fill('\u0000')
        }
    }

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

    private fun String.hexToBytes(): ByteArray? {
        if (length % 2 != 0) return null
        return runCatching {
            ByteArray(length / 2) { index ->
                substring(index * 2, index * 2 + 2).toInt(16).toByte()
            }
        }.getOrNull()
    }

    private fun constantTimeEquals(a: ByteArray, b: ByteArray): Boolean {
        if (a.size != b.size) return false
        var result = 0
        for (i in a.indices) result = result or (a[i].toInt() xor b[i].toInt())
        return result == 0
    }
}
