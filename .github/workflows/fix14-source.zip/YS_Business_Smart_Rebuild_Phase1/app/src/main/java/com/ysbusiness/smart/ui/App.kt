package com.ysbusiness.smart.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.sp
import com.ysbusiness.smart.data.*
import com.ysbusiness.smart.security.PasswordHasher
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.ysbusiness.smart.R
import com.ysbusiness.smart.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class Screen { STORE, OWNER, LOGIN, DASHBOARD }

@Composable
fun AppRoot(
    preferences: AppPreferences,
    onRequestBiometric: (onSuccess: () -> Unit, onUnavailable: () -> Unit) -> Unit
) {
    val snapshot by preferences.snapshot.collectAsState(initial = null)
    var showSplash by remember { mutableStateOf(true) }
    var splashStage by remember { mutableIntStateOf(1) }

    // One splash sequence only: first approved frame, then the branded frame.
    // Total duration is exactly five seconds; no second activity or repeated delay.
    LaunchedEffect(Unit) {
        delay(700)
        splashStage = 2
        delay(4_300)
        showSplash = false
    }

    if (showSplash) {
        SplashScreen(stage = splashStage)
        return
    }

    val current = snapshot
    if (current == null) {
        Box(Modifier.fillMaxSize().background(Navy), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Pink)
        }
        return
    }

    var screen by remember { mutableStateOf<Screen?>(null) }
    LaunchedEffect(current.storeCreated, current.ownerCreated) {
        if (screen == null) {
            screen = when {
                !current.storeCreated -> Screen.STORE
                !current.ownerCreated -> Screen.OWNER
                else -> Screen.LOGIN
            }
        }
    }

    val strings = remember(current.language) { S(current.language) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    SystemBarsEffect(darkMode = current.darkMode)

    // The application keeps one stable layout. Language changes translate text only;
    // controls, cards and navigation never jump to opposite sides.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        YSTheme(darkMode = current.darkMode) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                when (screen) {
                    Screen.STORE -> StoreSetupScreen(
                        s = strings,
                        darkMode = current.darkMode,
                        language = current.language,
                        onTheme = { scope.launch { preferences.setTheme(it) } },
                        onLanguage = { scope.launch { preferences.setLanguage(it) } },
                        onNext = { type, storeName, storeLogoUri ->
                            scope.launch {
                                // Base currency is configured later from Settings.
                                preferences.saveStore(
                                    type = type,
                                    currency = Currency.IQD,
                                    storeName = storeName,
                                    storeLogoUri = storeLogoUri
                                )
                                screen = Screen.OWNER
                            }
                        }
                    )

                    Screen.OWNER -> OwnerScreen(
                        s = strings,
                        darkMode = current.darkMode,
                        language = current.language,
                        onTheme = { scope.launch { preferences.setTheme(it) } },
                        onLanguage = { scope.launch { preferences.setLanguage(it) } },
                        onBack = { screen = Screen.STORE },
                        onCreate = { name, phone, email, profileImageUri, password ->
                            scope.launch {
                                preferences.saveOwner(name, phone, email, profileImageUri, password.toCharArray())
                                screen = Screen.LOGIN
                            }
                        }
                    )

                    Screen.LOGIN -> LoginScreen(
                        s = strings,
                        snapshot = current,
                        onTheme = { scope.launch { preferences.setTheme(it) } },
                        onLanguage = { scope.launch { preferences.setLanguage(it) } },
                        onProfileImageChange = { uri -> scope.launch { preferences.updateProfileImage(uri) } },
                        onPasswordLogin = { identifier, password, _ ->
                            val entered = identifier.trim()
                            val idMatches = entered.equals(current.phone, true) ||
                                entered.equals(current.email, true) ||
                                entered.equals(current.username, true)
                            val passwordMatches = PasswordHasher.verify(
                                password.toCharArray(), current.passwordSalt, current.passwordHash
                            )
                            if (idMatches && passwordMatches) {
                                scope.launch { preferences.enableBiometric(true) }
                                screen = Screen.DASHBOARD
                                true
                            } else {
                                false
                            }
                        },
                        onBiometric = {
                            onRequestBiometric(
                                { screen = Screen.DASHBOARD },
                                { Toast.makeText(context, strings.biometricUnavailable, Toast.LENGTH_SHORT).show() }
                            )
                        }
                    )

                    Screen.DASHBOARD -> DashboardScreen(
                        s = strings,
                        snapshot = current,
                        onTheme = { scope.launch { preferences.setTheme(it) } },
                        onLanguage = { scope.launch { preferences.setLanguage(it) } },
                        onCurrency = { scope.launch { preferences.setCurrency(it) } },
                        onLogout = { screen = Screen.LOGIN }
                    )

                    null -> Unit
                }
            }
        }
    }

    BackHandler(enabled = screen == Screen.OWNER || screen == Screen.DASHBOARD) {
        screen = when (screen) {
            Screen.OWNER -> Screen.STORE
            Screen.DASHBOARD -> Screen.LOGIN
            else -> screen
        }
    }
}

@Composable
private fun SplashScreen(stage: Int) {
    SplashSystemBarsEffect()
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF050727))
    ) {
        Image(
            painter = painterResource(
                if (stage == 1) R.drawable.splash_stage_one
                else R.drawable.splash_stage_two
            ),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
private fun SplashSystemBarsEffect() {
    val view = LocalView.current
    if (!view.isInEditMode) {
        DisposableEffect(Unit) {
            val window = (view.context as Activity).window
            val controller = WindowCompat.getInsetsController(window, view)
            controller.hide(WindowInsetsCompat.Type.systemBars())
            onDispose {
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }
}

@Composable
private fun StoreSetupScreen(
    s: S,
    darkMode: Boolean,
    language: AppLanguage,
    onTheme: (Boolean) -> Unit,
    onLanguage: (AppLanguage) -> Unit,
    onNext: (StoreType, String, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedType by rememberSaveable { mutableStateOf(StoreType.GENERAL) }
    var storeName by rememberSaveable { mutableStateOf("") }
    var storeLogoUri by rememberSaveable { mutableStateOf("") }
    var showPhotoOptions by rememberSaveable { mutableStateOf(false) }
    var pendingCropBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch { pendingCropBitmap = loadProfileBitmap(context, uri) }
        }
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) pendingCropBitmap = bitmap
    }

    if (showPhotoOptions) {
        PhotoSourceDialog(
            s = s,
            onDismiss = { showPhotoOptions = false },
            onCamera = {
                showPhotoOptions = false
                cameraLauncher.launch(null)
            },
            onGallery = {
                showPhotoOptions = false
                photoPicker.launch(arrayOf("image/*"))
            }
        )
    }

    pendingCropBitmap?.let { source ->
        ProfileCropDialog(
            source = source,
            s = s,
            onDismiss = { pendingCropBitmap = null },
            onSave = { cropped ->
                storeLogoUri = saveStoreLogoBitmap(context, cropped)
                pendingCropBitmap = null
            }
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopSettings(darkMode, language, onTheme, onLanguage)
        Spacer(Modifier.height(8.dp))
        Icon(
            Icons.Rounded.Storefront,
            null,
            tint = Color.White,
            modifier = Modifier
                .size(42.dp)
                .background(Pink, RoundedCornerShape(50))
                .padding(9.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text(s.createStore, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(18.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface.copy(alpha = .72f),
            border = BorderStroke(
                1.2.dp,
                Brush.horizontalGradient(
                    listOf(Pink.copy(alpha = .72f), Color(0xFF8B5CF6), Color(0xFF22D3EE))
                )
            ),
            tonalElevation = 0.dp,
            shadowElevation = 0.dp
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    contentAlignment = Alignment.BottomStart,
                    modifier = Modifier.clickable { showPhotoOptions = true }
                ) {
                    StoreLogoAvatar(storeLogoUri, 76.dp)
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFF25B7D8),
                        border = BorderStroke(2.dp, MaterialTheme.colorScheme.surface)
                    ) {
                        Icon(
                            Icons.Rounded.PhotoCamera,
                            null,
                            tint = Color.White,
                            modifier = Modifier.padding(6.dp).size(17.dp)
                        )
                    }
                }
                Spacer(Modifier.width(14.dp))
                OutlinedTextField(
                    value = storeName,
                    onValueChange = { storeName = it },
                    label = { Text(s.storeName) },
                    leadingIcon = { Icon(Icons.Rounded.Storefront, null, tint = Pink) },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Pink,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = .8f),
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SelectableTile(
                title = s.general,
                icon = Icons.Rounded.ShoppingCart,
                accent = Color(0xFFF04478),
                selected = selectedType == StoreType.GENERAL,
                onClick = { selectedType = StoreType.GENERAL },
                modifier = Modifier.weight(1f)
            )
            SelectableTile(
                title = s.grocery,
                icon = Icons.Rounded.ShoppingBasket,
                accent = Color(0xFF2F80ED),
                selected = selectedType == StoreType.GROCERY,
                onClick = { selectedType = StoreType.GROCERY },
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SelectableTile(
                title = s.clothing,
                icon = Icons.Rounded.Checkroom,
                accent = Color(0xFF8B5CF6),
                selected = selectedType == StoreType.CLOTHING,
                onClick = { selectedType = StoreType.CLOTHING },
                modifier = Modifier.weight(1f)
            )
            SelectableTile(
                title = s.pharmacy,
                icon = Icons.Rounded.LocalPharmacy,
                accent = Color(0xFF2ECF8F),
                selected = selectedType == StoreType.PHARMACY,
                onClick = { selectedType = StoreType.PHARMACY },
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(26.dp))
        PinkButton(
            s.next,
            {
                if (storeName.isBlank()) {
                    Toast.makeText(context, s.completeFields, Toast.LENGTH_SHORT).show()
                } else {
                    onNext(selectedType, storeName.trim(), storeLogoUri)
                }
            },
            Modifier.fillMaxWidth(),
            icon = Icons.Rounded.ArrowForward
        )
        Spacer(Modifier.navigationBarsPadding().height(14.dp))
    }
}

@Composable
private fun OwnerScreen(
    s: S,
    darkMode: Boolean,
    language: AppLanguage,
    onTheme: (Boolean) -> Unit,
    onLanguage: (AppLanguage) -> Unit,
    onBack: () -> Unit,
    onCreate: (String, String, String, String, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    var username by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var profileImageUri by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    var accepted by rememberSaveable { mutableStateOf(false) }
    var showPhotoOptions by rememberSaveable { mutableStateOf(false) }
    var pendingCropBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch { pendingCropBitmap = loadProfileBitmap(context, uri) }
        }
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) pendingCropBitmap = bitmap
    }

    if (showPhotoOptions) {
        PhotoSourceDialog(
            s = s,
            onDismiss = { showPhotoOptions = false },
            onCamera = {
                showPhotoOptions = false
                cameraLauncher.launch(null)
            },
            onGallery = {
                showPhotoOptions = false
                photoPicker.launch(arrayOf("image/*"))
            }
        )
    }

    pendingCropBitmap?.let { source ->
        ProfileCropDialog(
            source = source,
            s = s,
            onDismiss = { pendingCropBitmap = null },
            onSave = { cropped ->
                profileImageUri = saveProfileBitmap(context, cropped)
                pendingCropBitmap = null
            }
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 10.dp)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier.fillMaxWidth().height(52.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                HeaderActionButton(
                    icon = if (darkMode) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                    tint = if (darkMode) Color(0xFFFFC857) else Color(0xFF1C3557),
                    onClick = { onTheme(!darkMode) }
                )
                Spacer(Modifier.width(10.dp))
                LanguageMenu(language, onLanguage)
                Spacer(Modifier.weight(1f))
                HeaderActionButton(
                    icon = Icons.Rounded.ArrowBack,
                    tint = MaterialTheme.colorScheme.onSurface,
                    onClick = onBack
                )
            }
        }

        Spacer(Modifier.height(14.dp))
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                contentAlignment = Alignment.BottomStart,
                modifier = Modifier.clickable { showPhotoOptions = true }
            ) {
                Box(
                    modifier = Modifier
                        .size(78.dp)
                        .background(
                            Brush.sweepGradient(
                                listOf(Pink, Color(0xFF8B5CF6), Color(0xFF22D3EE), Pink)
                            ),
                            CircleShape
                        )
                        .padding(3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    ProfileAvatar(profileImageUri, 70.dp)
                }
                Surface(
                    shape = CircleShape,
                    color = Color(0xFF25B7D8),
                    border = BorderStroke(2.dp, MaterialTheme.colorScheme.background),
                    shadowElevation = 7.dp
                ) {
                    Icon(
                        Icons.Rounded.PhotoCamera,
                        null,
                        tint = Color.White,
                        modifier = Modifier.padding(7.dp).size(18.dp)
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(s.ownerAccount, fontSize = 27.sp, fontWeight = FontWeight.Black)
        }

        Spacer(Modifier.height(22.dp))
        NeonAppField(username, { username = it }, s.username, Icons.Rounded.AlternateEmail, AppFieldType.TEXT)
        NeonAppField(phone, { phone = it }, s.phone, Icons.Rounded.Phone, AppFieldType.PHONE)
        NeonAppField(email, { email = it }, s.email, Icons.Rounded.Email, AppFieldType.EMAIL)
        NeonAppField(password, { password = it }, s.password, Icons.Rounded.Lock, AppFieldType.PASSWORD)
        NeonAppField(confirm, { confirm = it }, s.confirmPassword, Icons.Rounded.Lock, AppFieldType.PASSWORD)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(accepted, { accepted = it })
            Text(s.accept)
        }
        Spacer(Modifier.height(12.dp))
        PinkButton(
            text = s.createAccount,
            onClick = {
                when {
                    username.isBlank() || phone.isBlank() || password.length < 8 || !accepted ->
                        Toast.makeText(context, s.completeFields, Toast.LENGTH_SHORT).show()
                    password != confirm ->
                        Toast.makeText(context, s.passwordMismatch, Toast.LENGTH_SHORT).show()
                    else -> {
                        focusManager.clearFocus(force = true)
                        keyboardController?.hide()
                        onCreate(username, phone, email, profileImageUri, password)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            icon = Icons.Rounded.PersonAdd
        )
        Spacer(Modifier.navigationBarsPadding().height(12.dp))
    }
}

@Composable
private fun LoginScreen(
    s: S,
    snapshot: AppSnapshot,
    onTheme: (Boolean) -> Unit,
    onLanguage: (AppLanguage) -> Unit,
    onProfileImageChange: (String) -> Unit,
    onPasswordLogin: (String, String, Boolean) -> Boolean,
    onBiometric: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    var identifier by rememberSaveable(snapshot.username) { mutableStateOf(snapshot.username) }
    var password by rememberSaveable { mutableStateOf("") }
    var remember by rememberSaveable { mutableStateOf(true) }
    var showPhotoOptions by rememberSaveable { mutableStateOf(false) }
    var pendingCropBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                pendingCropBitmap = loadProfileBitmap(context, uri)
            }
        }
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) pendingCropBitmap = bitmap
    }

    if (showPhotoOptions) {
        PhotoSourceDialog(
            s = s,
            onDismiss = { showPhotoOptions = false },
            onCamera = {
                showPhotoOptions = false
                cameraLauncher.launch(null)
            },
            onGallery = {
                showPhotoOptions = false
                photoPicker.launch(arrayOf("image/*"))
            }
        )
    }

    pendingCropBitmap?.let { source ->
        ProfileCropDialog(
            source = source,
            s = s,
            onDismiss = { pendingCropBitmap = null },
            onSave = { cropped ->
                onProfileImageChange(saveProfileBitmap(context, cropped))
                pendingCropBitmap = null
            }
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 26.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopSettings(snapshot.darkMode, snapshot.language, onTheme, onLanguage)
        Spacer(Modifier.height(20.dp))
        Box(
            contentAlignment = Alignment.BottomStart,
            modifier = Modifier.clickable { showPhotoOptions = true }
        ) {
            ProfileAvatar(snapshot.profileImageUri, 98.dp)
            Surface(
                shape = RoundedCornerShape(50),
                color = Color(0xFF26B7D8),
                border = BorderStroke(2.dp, MaterialTheme.colorScheme.background)
            ) {
                Icon(Icons.Rounded.PhotoCamera, null, tint = Color.White, modifier = Modifier.padding(7.dp).size(18.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(snapshot.username, fontWeight = FontWeight.Black, fontSize = 24.sp)
        Spacer(Modifier.height(6.dp))
        Text("YS Business Smart", color = MaterialTheme.colorScheme.onBackground.copy(alpha = .68f), fontSize = 16.sp)
        Spacer(Modifier.height(26.dp))
        Text(s.login, fontSize = 32.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(22.dp))
        AppField(identifier, { identifier = it }, s.identifier, Icons.Rounded.PersonOutline, AppFieldType.TEXT)
        AppField(password, { password = it }, s.password, Icons.Rounded.Lock, AppFieldType.PASSWORD)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(remember, { remember = it })
            Text(s.remember)
        }
        Spacer(Modifier.height(12.dp))
        PinkButton(s.login, {
            focusManager.clearFocus(force = true)
            keyboardController?.hide()
            if (!onPasswordLogin(identifier, password, remember)) {
                Toast.makeText(context, s.invalidLogin, Toast.LENGTH_SHORT).show()
            }
        }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Login)
        Spacer(Modifier.height(18.dp))
        OutlinedButton(
            onClick = onBiometric,
            modifier = Modifier.fillMaxWidth().height(60.dp),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.5.dp, Pink.copy(alpha = .8f)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Pink)
        ) {
            Icon(Icons.Rounded.Fingerprint, null, tint = Pink, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(10.dp))
            Text(s.secureLogin, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Spacer(Modifier.navigationBarsPadding().height(12.dp))
    }
}

@Composable
private fun DashboardScreen(
    s: S,
    snapshot: AppSnapshot,
    onTheme: (Boolean) -> Unit,
    onLanguage: (AppLanguage) -> Unit,
    onCurrency: (Currency) -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    var showLogoutDialog by rememberSaveable { mutableStateOf(false) }
    var showAccountMenu by remember { mutableStateOf(false) }
    var showSettingsDialog by rememberSaveable { mutableStateOf(false) }

    if (showLogoutDialog) {
        LogoutConfirmationDialog(
            s = s,
            onDismiss = { showLogoutDialog = false },
            onConfirm = {
                showLogoutDialog = false
                onLogout()
            }
        )
    }

    if (showSettingsDialog) {
        DashboardSettingsDialog(
            s = s,
            currency = snapshot.currency,
            onCurrency = onCurrency,
            onDismiss = { showSettingsDialog = false }
        )
    }

    val displayStoreName = snapshot.storeName.ifBlank {
        if (snapshot.username.isBlank()) "YS Business" else "متجر ${snapshot.username}"
    }

    Scaffold(
        topBar = {
            Surface(
                color = if (snapshot.darkMode) NavyHeader else Color.White,
                shadowElevation = 0.dp,
                tonalElevation = 0.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .heightIn(min = 76.dp)
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box {
                            ProfileAvatar(
                                imageUri = snapshot.profileImageUri,
                                size = 42.dp,
                                modifier = Modifier.clickable { showAccountMenu = true }
                            )
                            DropdownMenu(
                                expanded = showAccountMenu,
                                onDismissRequest = { showAccountMenu = false },
                                offset = DpOffset(0.dp, 8.dp),
                                shape = RoundedCornerShape(20.dp),
                                containerColor = MaterialTheme.colorScheme.surface,
                                tonalElevation = 8.dp,
                                shadowElevation = 12.dp
                            ) {
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(
                                                    snapshot.username.ifBlank { s.accountMenu },
                                                    fontWeight = FontWeight.Black,
                                                    fontSize = 17.sp
                                                )
                                                Text(
                                                    displayStoreName,
                                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f),
                                                    fontSize = 12.sp
                                                )
                                            }
                                        },
                                        leadingIcon = {
                                            Icon(Icons.Rounded.Person, null, tint = Pink)
                                        },
                                        enabled = false,
                                        onClick = {}
                                    )
                                    HorizontalDivider(
                                        color = MaterialTheme.colorScheme.outline.copy(alpha = .35f)
                                    )
                                    DropdownMenuItem(
                                        text = { Text(s.settings, fontWeight = FontWeight.Bold) },
                                        leadingIcon = {
                                            Icon(Icons.Rounded.Settings, null, tint = Color(0xFF8B5CF6))
                                        },
                                        onClick = {
                                            showAccountMenu = false
                                            showSettingsDialog = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(s.logoutTitle, fontWeight = FontWeight.Bold) },
                                        leadingIcon = {
                                            Icon(Icons.Rounded.Logout, null, tint = Pink)
                                        },
                                        onClick = {
                                            showAccountMenu = false
                                            showLogoutDialog = true
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.width(7.dp))
                        LanguageMenu(snapshot.language, onLanguage)
                        Spacer(Modifier.width(7.dp))
                        HeaderActionButton(
                            icon = if (snapshot.darkMode) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                            tint = if (snapshot.darkMode) Color(0xFFFFC857) else Color(0xFF1C3557),
                            onClick = { onTheme(!snapshot.darkMode) }
                        )

                        Spacer(Modifier.weight(1f))

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.widthIn(min = 66.dp, max = 92.dp)
                        ) {
                            StoreLogoAvatar(snapshot.storeLogoUri, 44.dp)
                            Spacer(Modifier.height(3.dp))
                            Text(
                                displayStoreName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                maxLines = 1,
                                softWrap = false,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            BottomHomeBar(s, snapshot.darkMode) {
                Toast.makeText(context, s.notReady, Toast.LENGTH_SHORT).show()
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            SalesCard(s, snapshot.currency)
            Spacer(Modifier.height(18.dp))
            val cards = listOf(
                Triple(s.cashier, Icons.Rounded.PointOfSale, Color(0xFF23B7F5)),
                Triple(s.inventory, Icons.Rounded.Inventory2, Color(0xFF8B5CF6)),
                Triple(s.customers, Icons.Rounded.Groups, Color(0xFF2ECF8F)),
                Triple(s.reports, Icons.Rounded.QueryStats, Color(0xFFFFA726)),
                Triple(s.expenses, Icons.Rounded.AccountBalanceWallet, Color(0xFFF43F72)),
                Triple(s.smartCenter, Icons.Rounded.SmartToy, Color(0xFFA855F7))
            )
            cards.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { (title, icon, color) ->
                        DashboardTile(title, icon, color, snapshot.darkMode, Modifier.weight(1f)) {
                            Toast.makeText(context, s.notReady, Toast.LENGTH_SHORT).show()
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
            }
            AlertRow(s.lowStock, "0", Icons.Rounded.WarningAmber)
            Spacer(Modifier.height(10.dp))
            AlertRow(s.dueInvoices, "0", Icons.Rounded.Schedule)
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun DashboardSettingsDialog(
    s: S,
    currency: Currency,
    onCurrency: (Currency) -> Unit,
    onDismiss: () -> Unit
) {
    var selected by remember(currency) { mutableStateOf(currency) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(.90f),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .45f)),
            shadowElevation = 18.dp
        ) {
            Column(
                Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Rounded.Settings,
                    null,
                    tint = Color(0xFF8B5CF6),
                    modifier = Modifier.size(34.dp)
                )
                Spacer(Modifier.height(8.dp))
                Text(s.settings, fontWeight = FontWeight.Black, fontSize = 24.sp)
                Spacer(Modifier.height(18.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CurrencyCard(
                        code = "IQD",
                        symbol = "د.ع",
                        name = s.iraqiDinar,
                        selected = selected == Currency.IQD,
                        onClick = { selected = Currency.IQD },
                        modifier = Modifier.weight(1f)
                    )
                    CurrencyCard(
                        code = "USD",
                        symbol = "$",
                        name = s.usDollar,
                        selected = selected == Currency.USD,
                        onClick = { selected = Currency.USD },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(20.dp))
                PinkButton(
                    text = s.save,
                    onClick = {
                        onCurrency(selected)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    icon = Icons.Rounded.Save
                )
            }
        }
    }
}

@Composable
private fun PhotoSourceDialog(
    s: S,
    onDismiss: () -> Unit,
    onCamera: () -> Unit,
    onGallery: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(.88f),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .35f)),
            shadowElevation = 18.dp
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                PhotoChoiceButton(
                    text = s.capturePhoto,
                    icon = Icons.Rounded.PhotoCamera,
                    accent = Color(0xFF26B7D8),
                    onClick = onCamera
                )
                PhotoChoiceButton(
                    text = s.choosePhone,
                    icon = Icons.Rounded.PhotoLibrary,
                    accent = Color(0xFF8B5CF6),
                    onClick = onGallery
                )
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text(s.cancel, color = Pink, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PhotoChoiceButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        color = accent.copy(alpha = .10f),
        border = BorderStroke(1.2.dp, accent.copy(alpha = .55f))
    ) {
        Row(
            Modifier.padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(accent.copy(alpha = .16f), RoundedCornerShape(13.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = accent, modifier = Modifier.size(25.dp))
            }
            Spacer(Modifier.width(14.dp))
            Text(text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
    }
}

@Composable
private fun TopSettings(
    darkMode: Boolean,
    language: AppLanguage,
    onTheme: (Boolean) -> Unit,
    onLanguage: (AppLanguage) -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(52.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            HeaderActionButton(
                icon = if (darkMode) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                tint = if (darkMode) Color(0xFFFFC857) else Color(0xFF1C3557),
                onClick = { onTheme(!darkMode) }
            )
            Spacer(Modifier.weight(1f))
            LanguageMenu(language, onLanguage)
        }
    }
}

@Composable
private fun HeaderActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.size(44.dp),
        shape = RoundedCornerShape(15.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .96f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .55f)),
        shadowElevation = 2.dp
    ) {
        IconButton(onClick = onClick) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(25.dp)
            )
        }
    }
}

@Composable
private fun LanguageMenu(language: AppLanguage, onLanguage: (AppLanguage) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        HeaderActionButton(
            icon = Icons.Rounded.Language,
            tint = Pink,
            onClick = { expanded = true }
        )
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            offset = DpOffset(x = 0.dp, y = 8.dp),
            shape = RoundedCornerShape(18.dp),
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            shadowElevation = 8.dp
        ) {
            LanguageItem("العربية", language == AppLanguage.ARABIC) {
                expanded = false
                onLanguage(AppLanguage.ARABIC)
            }
            LanguageItem("کوردی", language == AppLanguage.KURDISH) {
                expanded = false
                onLanguage(AppLanguage.KURDISH)
            }
            LanguageItem("English", language == AppLanguage.ENGLISH) {
                expanded = false
                onLanguage(AppLanguage.ENGLISH)
            }
        }
    }
}

@Composable
private fun LanguageItem(text: String, selected: Boolean, onClick: () -> Unit) {
    DropdownMenuItem(
        text = {
            Text(
                text,
                fontWeight = if (selected) FontWeight.Black else FontWeight.Medium
            )
        },
        leadingIcon = {
            if (selected) {
                Icon(Icons.Rounded.CheckCircle, null, tint = Pink)
            } else {
                Spacer(Modifier.size(24.dp))
            }
        },
        onClick = onClick
    )
}

@Composable
private fun LogoutConfirmationDialog(
    s: S,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(.88f)
                .wrapContentHeight(),
            shape = RoundedCornerShape(30.dp),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 24.dp,
            tonalElevation = 6.dp,
            border = BorderStroke(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = .35f)
            )
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Pink.copy(alpha = .13f),
                    border = BorderStroke(1.dp, Pink.copy(alpha = .35f))
                ) {
                    Icon(
                        Icons.Rounded.Logout,
                        contentDescription = null,
                        tint = Pink,
                        modifier = Modifier.padding(14.dp).size(30.dp)
                    )
                }
                Spacer(Modifier.height(18.dp))
                Text(
                    s.logoutMessage,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = .78f),
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Spacer(Modifier.height(24.dp))
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f).height(58.dp),
                            shape = RoundedCornerShape(17.dp),
                            border = BorderStroke(1.4.dp, Pink.copy(alpha = .65f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Pink),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(
                                    s.cancel,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                        Button(
                            onClick = onConfirm,
                            modifier = Modifier.weight(1f).height(58.dp),
                            shape = RoundedCornerShape(17.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Pink),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(
                                    s.logoutConfirm,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    maxLines = 1,
                                    softWrap = false,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SystemBarsEffect(darkMode: Boolean) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = if (darkMode) {
                android.graphics.Color.rgb(6, 27, 49)
            } else {
                android.graphics.Color.rgb(245, 247, 251)
            }
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkMode
                isAppearanceLightNavigationBars = !darkMode
            }
        }
    }
}

private enum class AppFieldType { TEXT, PHONE, EMAIL, PASSWORD }


@Composable
private fun NeonAppField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    fieldType: AppFieldType = AppFieldType.TEXT
) {
    val isPassword = fieldType == AppFieldType.PASSWORD
    val keyboardType = when (fieldType) {
        AppFieldType.PHONE -> KeyboardType.Phone
        AppFieldType.EMAIL -> KeyboardType.Email
        AppFieldType.PASSWORD -> KeyboardType.Password
        AppFieldType.TEXT -> KeyboardType.Text
    }

    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        leadingIcon = {
            Icon(
                icon,
                null,
                tint = if (value.isNotBlank()) Pink
                else MaterialTheme.colorScheme.onSurface.copy(alpha = .66f)
            )
        },
        visualTransformation = if (isPassword) PasswordVisualTransformation()
        else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            keyboardType = keyboardType,
            imeAction = ImeAction.Next
        ),
        singleLine = true,
        shape = RoundedCornerShape(19.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Pink,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = .86f),
            focusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = .60f),
            unfocusedContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = .48f),
            cursorColor = Pink
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
    )
}

@Composable
private fun AppField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    fieldType: AppFieldType = AppFieldType.TEXT
) {
    val isPassword = fieldType == AppFieldType.PASSWORD
    val keyboardType = when (fieldType) {
        AppFieldType.PHONE -> KeyboardType.Phone
        AppFieldType.EMAIL -> KeyboardType.Email
        AppFieldType.PASSWORD -> KeyboardType.Password
        AppFieldType.TEXT -> KeyboardType.Text
    }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        leadingIcon = { Icon(icon, null) },
        visualTransformation = if (isPassword) PasswordVisualTransformation()
        else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            keyboardType = keyboardType,
            imeAction = ImeAction.Next
        ),
        singleLine = true,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
    )
}

@Composable
private fun SalesCard(s: S, currency: Currency) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(176.dp)
            .background(Brush.linearGradient(listOf(PinkLight, Pink)), RoundedCornerShape(24.dp))
            .padding(22.dp)
    ) {
        Column {
            Text(s.todaySales, color = Color.White.copy(alpha = .9f))
            Spacer(Modifier.height(12.dp))
            Text(if (currency == Currency.IQD) "0 د.ع" else "$0", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(10.dp))
            Text("${s.invoices}: 0", color = Color.White)
        }
        Icon(Icons.Rounded.ShowChart, null, tint = Color.White.copy(alpha = .85f), modifier = Modifier.align(Alignment.CenterEnd).size(94.dp))
    }
}

@Composable
private fun DashboardTile(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    darkMode: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    Surface(
        modifier = modifier
            .height(132.dp)
            .clickable(onClick = onClick),
        shape = shape,
        color = if (darkMode) MaterialTheme.colorScheme.surface else Color.White,
        border = BorderStroke(1.35.dp, color.copy(alpha = if (darkMode) .58f else .48f)),
        shadowElevation = 0.dp,
        tonalElevation = 0.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    if (darkMode) {
                        Brush.linearGradient(
                            listOf(
                                color.copy(alpha = .18f),
                                MaterialTheme.colorScheme.surface,
                                color.copy(alpha = .07f)
                            )
                        )
                    } else {
                        Brush.verticalGradient(
                            listOf(
                                Color.White,
                                color.copy(alpha = .075f)
                            )
                        )
                    }
                )
                .padding(horizontal = 12.dp, vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .background(
                            if (darkMode) {
                                Brush.linearGradient(listOf(color.copy(alpha = .30f), color.copy(alpha = .12f)))
                            } else {
                                Brush.linearGradient(listOf(color.copy(alpha = .17f), color.copy(alpha = .07f)))
                            },
                            RoundedCornerShape(18.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, null, tint = color, modifier = Modifier.size(32.dp))
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    title,
                    modifier = Modifier.fillMaxWidth(),
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    softWrap = false,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun AlertRow(title: String, count: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = .45f))
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Pink)
            Spacer(Modifier.width(14.dp))
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold)
            Badge { Text(count) }
        }
    }
}

private data class BottomBarItem(
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color,
    val selected: Boolean = false
)

@Composable
private fun BottomHomeBar(
    s: S,
    darkMode: Boolean,
    onUnavailable: () -> Unit
) {
    val items = listOf(
        BottomBarItem(s.home, Icons.Rounded.Home, Pink, selected = true),
        BottomBarItem(s.cashier, Icons.Rounded.PointOfSale, Color(0xFF23B7F5)),
        BottomBarItem(s.inventory, Icons.Rounded.Inventory2, Color(0xFF8B5CF6)),
        BottomBarItem(s.customers, Icons.Rounded.Groups, Color(0xFF2ECF8F)),
        BottomBarItem(s.more, Icons.Rounded.MoreHoriz, Color(0xFFFFA726))
    )
    val barGradient = if (darkMode) {
        listOf(Color(0xFF0C2C4C), Color(0xFF281B3D), Color(0xFF0C2C4C))
    } else {
        listOf(Color(0xFFFFF1F6), Color(0xFFF2EEFF), Color(0xFFEFF9FF))
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        color = Color.Transparent,
        shadowElevation = 18.dp,
        tonalElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.horizontalGradient(barGradient))
                .navigationBarsPadding()
                .padding(horizontal = 8.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            items.forEach { item ->
                ColorfulBottomItem(
                    item = item,
                    modifier = Modifier.weight(1f),
                    onClick = { if (!item.selected) onUnavailable() }
                )
            }
        }
    }
}

@Composable
private fun ColorfulBottomItem(
    item: BottomBarItem,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(if (item.selected) 50.dp else 42.dp)
                .background(
                    brush = if (item.selected) {
                        Brush.linearGradient(listOf(PinkLight, Pink))
                    } else {
                        Brush.linearGradient(
                            listOf(item.color.copy(alpha = .22f), item.color.copy(alpha = .08f))
                        )
                    },
                    shape = RoundedCornerShape(if (item.selected) 18.dp else 15.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                item.icon,
                contentDescription = item.title,
                tint = if (item.selected) Color.White else item.color,
                modifier = Modifier.size(if (item.selected) 28.dp else 24.dp)
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            item.title,
            color = if (item.selected) Pink else item.color,
            fontWeight = if (item.selected) FontWeight.Black else FontWeight.Bold,
            fontSize = 11.sp,
            maxLines = 1
        )
    }
}
