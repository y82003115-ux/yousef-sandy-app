package com.ysbusiness.smart.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Pink = Color(0xFFF04478)
val PinkLight = Color(0xFFFF6B94)
val Navy = Color(0xFF061B31)
val NavyHeader = Color(0xFF0A2A4D)
val NavyCard = Color(0xFF0D3158)
val LightBackground = Color(0xFFF5F7FB)
val LightCard = Color(0xFFFFFFFF)
val Mint = Color(0xFF3DD6A4)

private val DarkColors = darkColorScheme(
    primary = Pink,
    secondary = PinkLight,
    background = Navy,
    surface = NavyCard,
    onPrimary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White,
    outline = Color(0xFF315679)
)

private val LightColors = lightColorScheme(
    primary = Pink,
    secondary = PinkLight,
    background = LightBackground,
    surface = LightCard,
    onPrimary = Color.White,
    onBackground = Color(0xFF14233B),
    onSurface = Color(0xFF14233B),
    outline = Color(0xFFD7DFEA)
)

@Composable
fun YSTheme(darkMode: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkMode) DarkColors else LightColors,
        content = content
    )
}
