package com.ysbusiness.smart

import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.ysbusiness.smart.data.AppPreferences
import com.ysbusiness.smart.ui.AppRoot

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Draw the background under system bars, while Compose adds safe insets so
        // controls never collide with the phone status or navigation bars.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        // Password-manager suggestions were corrupting the owner form on some devices.
        // This app keeps its own encrypted credential flow, so platform autofill is
        // deliberately disabled for every field.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.decorView.importantForAutofill =
                View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        }

        val preferences = AppPreferences(applicationContext)
        setContent {
            AppRoot(
                preferences = preferences,
                onRequestBiometric = { onSuccess, onUnavailable ->
                    showBiometricPrompt(onSuccess, onUnavailable)
                }
            )
        }
    }

    private fun showBiometricPrompt(onSuccess: () -> Unit, onUnavailable: () -> Unit) {
        // Use strong enrolled biometrics only. No device PIN/pattern fallback is offered.
        // Android owns the system prompt and chooses the enrolled strong modality.
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG

        val manager = BiometricManager.from(this)
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            onUnavailable()
            return
        }

        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    Toast.makeText(
                        this@MainActivity,
                        "لم يتم التحقق، حاول مرة أخرى",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    if (
                        errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                        errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                        errorCode != BiometricPrompt.ERROR_CANCELED
                    ) {
                        Toast.makeText(this@MainActivity, errString, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )

        val builder = BiometricPrompt.PromptInfo.Builder()
            .setTitle("الدخول الآمن")
            .setSubtitle("المس مستشعر البصمة")
            .setConfirmationRequired(false)
            .setAllowedAuthenticators(authenticators)
            .setNegativeButtonText("إلغاء")

        prompt.authenticate(builder.build())
    }
}
