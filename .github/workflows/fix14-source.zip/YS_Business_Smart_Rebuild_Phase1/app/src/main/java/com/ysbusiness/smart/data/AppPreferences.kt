package com.ysbusiness.smart.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.ysbusiness.smart.security.PasswordHasher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "ys_business_phase1")

enum class StoreType { GENERAL, GROCERY, CLOTHING, PHARMACY }
enum class Currency { IQD, USD }
enum class AppLanguage { ARABIC, KURDISH, ENGLISH }

data class AppSnapshot(
    val storeCreated: Boolean = false,
    val ownerCreated: Boolean = false,
    val storeType: StoreType = StoreType.GENERAL,
    val currency: Currency = Currency.IQD,
    val storeName: String = "",
    val storeLogoUri: String = "",
    val username: String = "",
    val phone: String = "",
    val email: String = "",
    val profileImageUri: String = "",
    val passwordSalt: String = "",
    val passwordHash: String = "",
    val darkMode: Boolean = true,
    val language: AppLanguage = AppLanguage.ARABIC,
    val biometricEnabled: Boolean = true
)

class AppPreferences(private val context: Context) {
    private object Keys {
        val storeCreated = booleanPreferencesKey("store_created")
        val ownerCreated = booleanPreferencesKey("owner_created")
        val storeType = stringPreferencesKey("store_type")
        val currency = stringPreferencesKey("currency")
        val storeName = stringPreferencesKey("store_name")
        val storeLogoUri = stringPreferencesKey("store_logo_uri")
        val username = stringPreferencesKey("username")
        val legacyOwnerName = stringPreferencesKey("owner_name")
        val phone = stringPreferencesKey("phone")
        val email = stringPreferencesKey("email")
        val profileImageUri = stringPreferencesKey("profile_image_uri")
        val passwordSalt = stringPreferencesKey("password_salt")
        val passwordHash = stringPreferencesKey("password_hash")
        val darkMode = booleanPreferencesKey("dark_mode")
        val language = stringPreferencesKey("language")
        val biometricEnabled = booleanPreferencesKey("biometric_enabled")
    }

    val snapshot: Flow<AppSnapshot> = context.dataStore.data.map { p ->
        AppSnapshot(
            storeCreated = p[Keys.storeCreated] ?: false,
            ownerCreated = p[Keys.ownerCreated] ?: false,
            storeType = enumValueOrDefault(p[Keys.storeType], StoreType.GENERAL),
            currency = enumValueOrDefault(p[Keys.currency], Currency.IQD),
            storeName = p[Keys.storeName].orEmpty(),
            storeLogoUri = p[Keys.storeLogoUri].orEmpty(),
            username = p[Keys.username]
                ?: p[Keys.email]?.substringBefore("@")?.takeIf { it.isNotBlank() }
                ?: p[Keys.phone]?.takeIf { it.isNotBlank() }
                ?: p[Keys.legacyOwnerName].orEmpty(),
            phone = p[Keys.phone].orEmpty(),
            email = p[Keys.email].orEmpty(),
            profileImageUri = p[Keys.profileImageUri].orEmpty(),
            passwordSalt = p[Keys.passwordSalt].orEmpty(),
            passwordHash = p[Keys.passwordHash].orEmpty(),
            darkMode = p[Keys.darkMode] ?: true,
            language = enumValueOrDefault(p[Keys.language], AppLanguage.ARABIC),
            biometricEnabled = p[Keys.biometricEnabled] ?: true
        )
    }

    suspend fun saveStore(
        type: StoreType,
        currency: Currency,
        storeName: String,
        storeLogoUri: String
    ) {
        context.dataStore.edit {
            it[Keys.storeCreated] = true
            it[Keys.storeType] = type.name
            it[Keys.currency] = currency.name
            it[Keys.storeName] = storeName.trim()
            it[Keys.storeLogoUri] = storeLogoUri
        }
    }

    suspend fun setCurrency(currency: Currency) {
        context.dataStore.edit { it[Keys.currency] = currency.name }
    }

    suspend fun updateStoreIdentity(storeName: String, storeLogoUri: String) {
        context.dataStore.edit {
            it[Keys.storeName] = storeName.trim()
            it[Keys.storeLogoUri] = storeLogoUri
        }
    }

    suspend fun saveOwner(
        username: String,
        phone: String,
        email: String,
        profileImageUri: String,
        password: CharArray
    ) {
        val result = PasswordHasher.hash(password)
        context.dataStore.edit {
            it[Keys.ownerCreated] = true
            it[Keys.username] = username.trim()
            it[Keys.phone] = phone.trim()
            it[Keys.email] = email.trim()
            it[Keys.profileImageUri] = profileImageUri
            it[Keys.passwordSalt] = result.saltBase64
            it[Keys.passwordHash] = result.hashBase64
            // The owner has just created the account on this device, so biometric login
            // can be offered immediately. Android still requires the enrolled device biometric.
            it[Keys.biometricEnabled] = true
        }
    }

    suspend fun updateProfileImage(uri: String) {
        context.dataStore.edit { it[Keys.profileImageUri] = uri }
    }

    suspend fun setTheme(dark: Boolean) {
        context.dataStore.edit { it[Keys.darkMode] = dark }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.language] = language.name }
    }

    suspend fun enableBiometric(enabled: Boolean) {
        context.dataStore.edit { it[Keys.biometricEnabled] = enabled }
    }

    private inline fun <reified T : Enum<T>> enumValueOrDefault(raw: String?, fallback: T): T =
        runCatching { enumValueOf<T>(raw.orEmpty()) }.getOrDefault(fallback)
}
