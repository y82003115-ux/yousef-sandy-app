# Phase 1: no custom shrinking rules yet.
